PLUGIN.name = "Faction Transfer Command"
PLUGIN.author = "Zenolisk"
PLUGIN.desc = "Adds a comamnd allowing you to force a player to another faction."
nut.util.Include("sh_commands.lua")