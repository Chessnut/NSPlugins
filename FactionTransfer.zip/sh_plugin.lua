PLUGIN.name = "Faction Transfer Command"
PLUGIN.author = "Green :3"
PLUGIN.desc = "Adds a comamnd allowing you to force a player to another faction."
nut.util.Include("sh_commands.lua")