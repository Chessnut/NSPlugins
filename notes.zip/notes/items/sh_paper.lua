ITEM.name = "Paper"
ITEM.uniqueID = "paper"
ITEM.category = "Consumable - Misc"
ITEM.model = Model( "models/props_junk/garbage_newspaper001a.mdl" )
ITEM.desc = "The paper that you can write something on"