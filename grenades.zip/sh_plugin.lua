PLUGIN.name = "Lamp"
PLUGIN.author = "Black Tea"
PLUGIN.desc = "A Lamp Item."

PLUGIN.flashlightRange = 800

if CLIENT then
	
	PLUGIN.FlashLight = {
		color = Color( 255, 255, 255 ),
		brightness = 5,
		size = 200,
	}
	PLUGIN.LampLight = {
		color = Color( 255, 255, 255 ),
		brightness = 3,
		size = 256,
	}
	function PLUGIN:Think()
		for k, v in pairs( player.GetAll() ) do
			if !v:IsValid() then return end
			if v:GetNetVar( "lampOn", false ) then
				local dlight = DynamicLight( v:EntIndex() )
				if ( dlight ) then
					local c = self.LampLight.color
					dlight.Pos = v:GetPos() + Vector( 0, 0, 50 ) + v:GetAimVector()*10
					dlight.r = c.r
					dlight.g = c.g
					dlight.b = c.b
					dlight.Brightness = self.LampLight.brightness
					dlight.Size = self.LampLight.size
					dlight.Decay = self.LampLight.size * 5
					dlight.DieTime = CurTime() + 1
				end
			end
			
			if v:GetNetVar( "flashlightOn", false ) then
				local data = {}
					data.start = v:GetShootPos()
					data.endpos = data.start + v:GetAimVector()*self.flashlightRange
					data.filter = v
					data.mask = MASK_SHOT
				local trace = util.TraceLine(data)
				local length = v:GetShootPos():Distance( trace.HitPos )
				local brightpercent = 1 - math.Clamp( length/self.flashlightRange, 0, 1 )
			
				local dlight = DynamicLight( v:EntIndex() )
				if ( dlight ) then
					local c = self.FlashLight.color
					dlight.Pos = trace.HitPos + trace.HitNormal * 1
					dlight.r = c.r
					dlight.g = c.g
					dlight.b = c.b
					dlight.Style = "mamamamamama"
					dlight.Brightness = self.FlashLight.brightness * brightpercent
					dlight.Size = self.FlashLight.size * math.Clamp( ( 1 - brightpercent ), .05, 1 )
					dlight.Decay = self.FlashLight.size * 5
					dlight.DieTime = CurTime() + 1
				end
			end
		end	
	end

else
	function PLUGIN:DoPlayerDeath( player )
		player:SetNetVar( "lampOn", false )
		player:SetNetVar( "flashlightOn", false )
	end
	
	function PLUGIN:OnItemDropped( client, itemTable, ent )
		if itemTable.uniqueID == "lamp" then
			client:SetNetVar( "lampOn", false )
			client:SetNetVar( "flashlightOn", false )
		end
	end
end

