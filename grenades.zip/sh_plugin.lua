PLUGIN.name = "Grenade Throwables"
PLUGIN.author = "Black Tea"
PLUGIN.desc = "Grenade Throwables."

local buffPLUGIN = nut.plugin.Get( "buffs" )
if not buffPLUGIN then
	print( 'Tear Gas Grenade will not work without "buffs" plugin!' )
else
	function PLUGIN:CanTearGassed( player )
		return true -- If some faction or item prevents from tear gassed, just mod this.
	end

	buffPLUGIN.buffs[ "teargas" ] = {
		name = "Tear Gas",
		desc = "Your action will be limited due the effect of tear gas.",
		onbuffed = function( player, parameter )
			if !player:HasBuff( "teargas" ) then
				player:ChatPrint( "You're gassed by the tear gas grenade." )
			end
		end,
		ondebuffed = function( player, parameter )
			if !player:Alive() then return end
			if player:HasBuff( "teargas" ) then
				player:ChatPrint( "Tear Gas's effect has worn out." )
			end
		end,
		func = function( player, parameter)
			player.timeNextCough = player.timeNextCough or CurTime()
			if player.timeNextCough < CurTime() then
				player:EmitSound( Format( "ambient/voices/cough%d.wav", math.random( 1, 4 ) ) )
				player.timeNextCough = CurTime() + 2
			end
		end,
	} 

	function PLUGIN:Move( ply, mv )
		if ply:GetMoveType() == 8 then return end
		if ply:HasBuff( "teargas" ) and ply:GetMoveType() == MOVETYPE_WALK then
			local m = .25
			local f = mv:GetForwardSpeed() 
			local s = mv:GetSideSpeed() 
			mv:SetForwardSpeed( f * .005 )
			mv:SetSideSpeed( s * .005 )
		end
	end

	local trg = 0
	local cur = 0
	function PLUGIN:HUDPaint()
		if LocalPlayer():HasBuff( "teargas" ) then 
			trg = 120 + math.abs( math.sin( RealTime()*2 )*70 )
		else
			trg = 0
		end
		cur = Lerp( FrameTime()*3, cur, trg )
		surface.SetDrawColor( 255, 255, 255, cur)
		surface.DrawRect(0, 0, ScrW(), ScrH())
	end
end