ITEM.name = "Flare - Green"
ITEM.model = "models/Items/grenadeAmmo.mdl"
ITEM.desc = "A Flare that emits strong green light."
ITEM.throwent = "nut_flare_g"
ITEM.throwforce = 500