ITEM.name = "Flare - Yellow"
ITEM.model = "models/Items/grenadeAmmo.mdl"
ITEM.desc = "A Flare that emits strong yellow light."
ITEM.throwent = "nut_flare_y"
ITEM.throwforce = 500