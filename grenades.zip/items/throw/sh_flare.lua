ITEM.name = "Flare - Red"
ITEM.model = "models/Items/grenadeAmmo.mdl"
ITEM.desc = "A Flare that emits strong red light."
ITEM.throwent = "nut_flare"
ITEM.throwforce = 500