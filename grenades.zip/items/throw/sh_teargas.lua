ITEM.name = "Tear Gas Grenade"
ITEM.model = "models/Items/grenadeAmmo.mdl"
ITEM.desc = "A Tear gas grenade that can disable opponents."
ITEM.throwent = "nut_teargas"
ITEM.throwforce = 500