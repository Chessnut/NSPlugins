local PLUGIN = PLUGIN
PLUGIN.name = "Anti-Kimchi"
PLUGIN.author = "Black Tea"
PLUGIN.desc = "Anti-Kimchi RP"

local prohibited = {
	"ㄱ",
	"ㄴ",
	"ㄷ",
	"ㄹ",
	"ㅁ",
	"ㅂ",
	"ㅅ",
	"ㅇ",
	"ㅈ",
	"ㅊ",
	"ㅋ",
	"ㅌ",
	"ㅍ",
	"ㅎ",
}

function PLUGIN:ChatClassPreText( class, speaker, text, mode)
	for _, t in pairs( prohibited ) do
		if !( mode == "ooc" or mode == "event" or mode == "looc" ) then
			if string.find( text, t ) then
				if LocalPlayer() == speaker then
					nut.util.Notify( "초성어 텍스트는 IC에서 금지되어 있습니다.", speaker)
				end
				return true
			end
		end
	end
	return false
end