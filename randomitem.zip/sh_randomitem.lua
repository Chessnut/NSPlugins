local PLUGIN = PLUGIN
PLUGIN.name = "Resource Distribution"
PLUGIN.author = "Black Tea"
PLUGIN.desc = "Distributes the resource randomly all over the world contianer.."

if SERVER then

	NUT_ITEM_WORLDCONTAINER_REGEN = CreateConVar( "nut_worldcontainer_regen", 600, FCVAR_NONE, "Adjust Zombie's Health" )
	
	REGEN_FOOD = 1
	REGEN_AMMO = 2
	REGEN_WEAPON = 3
	
	NUT_ITEM_REGEN_GROUP = {
	
		["frdg_small"] = {
			[ REGEN_FOOD ] = { 
				["food_btsoda"] = { chance = 200, amount = { 1, 4 } } ,
				["food_canned_1"] = { chance = 200, amount = { 1, 3 } } ,
				["food_chinese"] = { chance = 100, amount = { 1, 2 } } ,
				["food_soda_pb"] = { chance = 50, amount = { 1, 2 } } ,
				["food_milk_c"] = { chance = 50, amount = { 1, 2 } } ,
				["food_juice"] = { chance = 25, amount = { 1, 2 } } ,
				["food_milk_pb"] = { chance = 25, amount = { 1, 2 } } ,
				["food_vodka"] = { chance = 10, amount = { 1, 2 } } ,
				["food_stew"] = { chance = 10, amount = { 1, 2 } } ,
				["food_canham"] = { chance = 50, amount = { 1, 3 } } ,
				["food_canpasta"] = { chance = 50, amount = { 1, 3 } } ,
				["food_cansoup"] = { chance = 50, amount = { 1, 2 } } ,
				["food_cansoup"] = { chance = 50, amount = { 1, 2 } } ,
				["food_potatochip"] = { chance = 50, amount = { 1, 2 } } ,
				["food_chocolate"] = { chance = 50, amount = { 1, 2 } } ,
				["food_edrink"] = { chance = 50, amount = { 1, 2 } } ,
				["food_gato"] = { chance = 50, amount = { 1, 2 } } ,
				["food_granola"] = { chance = 50, amount = { 1, 2 } } ,
				["food_juice_pack"] = { chance = 50, amount = { 1, 2 } } ,
				["food_mre"] = { chance = 20, amount = { 1, 2 } } ,
				["food_water_s"] = { chance = 50, amount = { 1, 4 } } ,
				["food_water_l"] = { chance = 50, amount = { 1, 4 } } ,
			},
		},
		
		["frdg_big"] = {
			[ REGEN_FOOD ] = { 
				["food_btsoda"] = { chance = 400, amount = { 1, 4 } } ,
				["food_canned_1"] = { chance = 400, amount = { 1, 3 } } ,
				["food_chinese"] = { chance = 200, amount = { 1, 2 } } ,
				["food_soda_pb"] = { chance = 100, amount = { 1, 2 } } ,
				["food_milk_c"] = { chance = 100, amount = { 1, 2 } } ,
				["food_juice"] = { chance = 50, amount = { 1, 2 } } ,
				["food_milk_pb"] = { chance = 50, amount = { 1, 2 } } ,
				["food_vodka"] = { chance = 20, amount = { 1, 2 } } ,
				["food_stew"] = { chance = 20, amount = { 1, 2 } } ,
				["food_canham"] = { chance = 100, amount = { 1, 3 } } ,
				["food_canpasta"] = { chance = 100, amount = { 1, 3 } } ,
				["food_cansoup"] = { chance = 100, amount = { 1, 2 } } ,
				["food_cansoup"] = { chance = 100, amount = { 1, 2 } } ,
				["food_potatochip"] = { chance = 100, amount = { 1, 2 } } ,
				["food_chocolate"] = { chance = 100, amount = { 1, 2 } } ,
				["food_edrink"] = { chance = 100, amount = { 1, 2 } } ,
				["food_gato"] = { chance = 100, amount = { 1, 2 } } ,
				["food_granola"] = { chance = 100, amount = { 1, 2 } } ,
				["food_juice_pack"] = { chance = 100, amount = { 1, 2 } } ,
				["food_mre"] = { chance = 100, amount = { 1, 2 } } ,
				["food_water_s"] = { chance = 100, amount = { 1, 4 } } ,
				["food_water_l"] = { chance = 100, amount = { 1, 4 } } ,
			},
		},
		
		["vendor"] = {
			[ REGEN_FOOD ] = { 
				["food_btsoda"] = { chance = 100, amount = { 1, 2 } } ,
				["food_milk_c"] = { chance = 20, amount = { 1, 1 } } ,
				["food_juice"] = { chance = 20, amount = { 1, 1 } } ,
				["food_milk_pb"] = { chance = 20, amount = { 1, 1 } } ,
				["food_vodka"] = { chance = 10, amount = { 1, 1 } } ,
				["food_edrink"] = { chance = 10, amount = { 1, 1 } } ,
				["food_gato"] = { chance = 15, amount = { 1, 1 } } ,
				["food_juice_pack"] = { chance = 50, amount = { 1, 1 } } ,
				["food_water_s"] = { chance = 200, amount = { 1, 1 } } ,
				["food_water_l"] = { chance = 200, amount = { 1, 1 } } ,
			},
		},
	
		["default"] = {
			[ REGEN_FOOD ] = { 
				["buff_Detoxer"] = { chance = 100, amount = { 1, 1 } },
				["buff_neuro"] = { chance = 10, amount = { 1, 1 } },
				["buff_medickit"] = { chance = 50, amount = { 1, 1 } },
				["buff_medivial"] = { chance = 70, amount = { 1, 2 } },
				
				["food_btsoda"] = { chance = 200, amount = { 1, 2 } } ,
				["food_canned_1"] = { chance = 200, amount = { 1, 2 } } ,
				["food_chinese"] = { chance = 100, amount = { 1, 1 } } ,
				["food_soda_pb"] = { chance = 50, amount = { 1, 1 } } ,
				["food_milk_c"] = { chance = 50, amount = { 1, 1 } } ,
				["food_juice"] = { chance = 25, amount = { 1, 1 } } ,
				["food_milk_pb"] = { chance = 25, amount = { 1, 1 } } ,
				["food_vodka"] = { chance = 10, amount = { 1, 1 } } ,
				["food_stew"] = { chance = 10, amount = { 1, 1 } } ,
				["food_canham"] = { chance = 50, amount = { 1, 2 } } ,
				["food_canpasta"] = { chance = 50, amount = { 1, 2 } } ,
				["food_cansoup"] = { chance = 50, amount = { 1, 1 } } ,
				["food_cansoup"] = { chance = 50, amount = { 1, 1 } } ,
				["food_potatochip"] = { chance = 50, amount = { 1, 1 } } ,
				["food_chocolate"] = { chance = 50, amount = { 1, 1 } } ,
				["food_edrink"] = { chance = 50, amount = { 1, 1 } } ,
				["food_gato"] = { chance = 50, amount = { 1, 1 } } ,
				["food_granola"] = { chance = 50, amount = { 1, 1 } } ,
				["food_juice_pack"] = { chance = 50, amount = { 1, 1 } } ,
				["food_mre"] = { chance = 20, amount = { 1, 1 } } ,
				["food_water_s"] = { chance = 50, amount = { 1, 1 } } ,
				["food_water_l"] = { chance = 50, amount = { 1, 1 } } ,
			},
			[ REGEN_AMMO ] = {
				["a_30_pistol"] = { chance = 25, amount = { 1, 2 } } ,
				["a_30_smg"] = { chance = 10, amount = { 1, 1 } } ,
				["a_10_buckshot"] = { chance = 10, amount = { 1, 1 } } ,
				["a_30_ar2"] = { chance = 5, amount = { 1, 1 } } ,
				["a_10_357"] = { chance = 5, amount = { 1, 1 } } ,
				["a_2_sniper"] = { chance = 5, amount = { 1, 1 } } ,
				["radio"] = { chance = 10, amount = { 1, 1 } } ,
			},
			[ REGEN_WEAPON ] = {
				["hl2_m_wrench"] = { chance = 11, amount = { 1, 1 } } ,
				["hl2_m_machate"] = { chance = 11, amount = { 1, 1 } } ,
				["hl2_m_knife"] = { chance = 11, amount = { 1, 1 } } ,
				["hl2_m_hammer"] = { chance = 11, amount = { 1, 1 } } ,
				["hl2_m_fireaxe"] = { chance = 11, amount = { 1, 1 } } ,
				["hl2_m_crowbar"] = { chance = 11, amount = { 1, 1 } } ,
				["hl2_m_batnail"] = { chance = 11, amount = { 1, 1 } } ,
				["hl2_m_bat"] = { chance = 11, amount = { 1, 1 } } ,
				["hl2_m_axe"] = { chance = 11, amount = { 1, 1 } } ,
				
				["hl2_r_pistol"] = { chance = 4, amount = { 1, 1 } } ,
				["hl2_r_ar2"] = { chance = 1, amount = { 1, 1 } } ,
				["hl2_r_smg1"] = { chance = 2, amount = { 1, 1 } } ,
				["hl2_r_mp5k"] = { chance = 2, amount = { 1, 1 } } ,
				["hl2_r_ar3"] = { chance = 2, amount = { 1, 1 } } ,
				["hl2_r_ar3c"] = { chance = 2, amount = { 1, 1 } } ,
				["hl2_r_cmbpist"] = { chance = 2, amount = { 1, 1 } } ,
				["hl2_r_shotgun"] = { chance = 1, amount = { 1, 1 } } ,
				["hl2_r_revolver"] = { chance = 1, amount = { 1, 1 } } ,
				["hl2_r_sniper"] = { chance = 1, amount = { 1, 1 } } ,
			}
		},
	
	}
	
	NUT_ITEM_REGEN_MODEL = {
		["models/props_interiors/vendingmachinesoda01a.mdl"] = "vendor",
		["models/props_c17/furniturefridge001a.mdl"] = "frdg_small",
		["models/props_wasteland/kitchen_fridge001a.mdl"] = "frdg_big",
	}
	
	
	NUT_NEXTREGEN = NUT_NEXTREGEN or CurTime()
	function PLUGIN:Think()
		if NUT_NEXTREGEN < CurTime() then
			print( 'Updated Contianer.' )
			for _, v in pairs(  ents.FindByClass( "nut_container" ) ) do
				if v.world then
					v:SetNetVar("inv", {})
					
					local mdl = string.lower( v:GetModel() )
					local str = NUT_ITEM_REGEN_MODEL[ mdl ] or "default"
					local itmtbl = NUT_ITEM_REGEN_GROUP[ str ] 
					if !itmtbl then print("ITEM TABLE IS NOT EXISTS.") itmtbl = NUT_ITEM_REGEN_GROUP[ "default" ]  end
					
					for _, tbl in pairs( itmtbl ) do
						for item, dat in pairs( tbl ) do
							local dice = math.random( 1, 1000 )
							if dat.chance >= dice then
								local amt = math.random( dat.amount[1], dat.amount[2] )
								v:UpdateInv( item, amt, {}  )
							end
						end
					end
					
				end
			end
			NUT_NEXTREGEN = CurTime() + NUT_ITEM_WORLDCONTAINER_REGEN:GetInt()
		end
	end
	
	function dbg_regen()
		NUT_NEXTREGEN = CurTime() 
	end
	
	local tblStorage = {}
	function PLUGIN:DoSearch()
		for uid, dat in pairs( nut.item.GetAll() ) do
			if dat.category == "Storage" then
				tblStorage[ string.lower( dat.model ) ] = dat
			end
		end
		
		for k,v in pairs( ents.GetAll() ) do
			if !v:GetModel() then continue end
			if tblStorage[ string.lower( v:GetModel() ) ] then
				local dat = tblStorage[ string.lower( v:GetModel() ) ]
				local entity = ents.Create("nut_container")
				entity:SetPos( v:GetPos() )
				entity:SetAngles( v:GetAngles() )
				entity:Spawn()
				entity:Activate()
				entity:SetNetVar("inv", {})
				entity:SetNetVar("name", dat.name)
				entity.generated = true
				entity.world = true
				entity.itemID = dat.uniqueID
				if (dat.maxWeight) then
					entity:SetNetVar("max", dat.maxWeight)
				end
				entity:SetModel(dat.model)
				entity:PhysicsInit( SOLID_VPHYSICS )
				entity:SetMoveType( MOVETYPE_NONE )
				v:Remove()
				if v:IsValid() then
					v:Remove()
				end
				
			end
		end
	end
	
	function PLUGIN:InitPostEntity( )
		do
			self:DoSearch()
		end
	end
	
end