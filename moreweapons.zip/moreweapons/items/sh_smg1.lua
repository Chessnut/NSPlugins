ITEM.name = "SMG"
ITEM.base = "base_wep"
ITEM.uniqueID = "hl2_smg1"
ITEM.category = nut.lang.Get("weapons_ranged")
ITEM.class = "hl2_r_smg1"
ITEM.type = "primary"
ITEM.model = Model( "models/Weapons/w_smg1.mdl" )
ITEM.desc = nut.lang.Get("desc_wep_smg1")