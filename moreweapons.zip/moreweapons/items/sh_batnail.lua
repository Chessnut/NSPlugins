ITEM.name = "Nailed Bat"
ITEM.base = "base_wep"
ITEM.uniqueID = "hl2_m_batnail"
ITEM.category = nut.lang.Get("weapons_melee")
ITEM.class = "hl2_m_batnail"
ITEM.type = "melee"
ITEM.model = Model( "models/warz/melee/baseballbat_spike.mdl" )
ITEM.desc = "A Nailed Bat"