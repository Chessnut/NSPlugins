ITEM.name = "Machete"
ITEM.base = "base_wep"
ITEM.uniqueID = "hl2_m_machate"
ITEM.category = nut.lang.Get("weapons_melee")
ITEM.class = "hl2_m_machate"
ITEM.type = "melee"
ITEM.model = Model( "models/warz/melee/machete.mdl" )
ITEM.desc = "A Machete"