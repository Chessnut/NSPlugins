ITEM.name = "AR2 Standard Issue"
ITEM.base = "base_wep"
ITEM.uniqueID = "hl2_ar2"
ITEM.category = nut.lang.Get("weapons_ranged")
ITEM.class = "hl2_r_ar2"
ITEM.type = "primary"
ITEM.model = Model( "models/Weapons/w_IRifle.mdl" )
ITEM.desc = nut.lang.Get("desc_wep_ar2")