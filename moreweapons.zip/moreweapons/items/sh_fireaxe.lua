ITEM.name = "Fire Axe"
ITEM.base = "base_wep"
ITEM.uniqueID = "hl2_m_fireaxe"
ITEM.category = nut.lang.Get("weapons_melee")
ITEM.class = "hl2_m_fireaxe"
ITEM.type = "melee"
ITEM.model = Model( "models/warz/melee/fireaxe.mdl" )
ITEM.desc = "A Fire Axe"