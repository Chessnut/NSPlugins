ITEM.name = "AR3 Carbine"
ITEM.base = "base_wep"
ITEM.uniqueID = "hl2_ar3c"
ITEM.category = nut.lang.Get("weapons_ranged")
ITEM.class = "hl2_r_ar3c"
ITEM.type = "primary"
ITEM.model = Model( "models/Weapons/w_ar3c.mdl" )
ITEM.desc = "AR3 Carbine Standard - Metro Issue"