ITEM.name = "AR3 Rifle"
ITEM.base = "base_wep"
ITEM.uniqueID = "hl2_ar3"
ITEM.category = nut.lang.Get("weapons_ranged")
ITEM.class = "hl2_r_ar3"
ITEM.type = "primary"
ITEM.model = Model( "models/Weapons/w_ar3car.mdl" )
ITEM.desc = "AR3 Standard Combine Rifle"