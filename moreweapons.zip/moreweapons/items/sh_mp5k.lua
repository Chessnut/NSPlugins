ITEM.name = "MP5 Kurz"
ITEM.base = "base_wep"
ITEM.uniqueID = "hl2_mp5k"
ITEM.category = nut.lang.Get("weapons_ranged")
ITEM.class = "hl2_r_mp5k"
ITEM.type = "primary"
ITEM.model = Model( "models/Weapons/w_smg2.mdl" )
ITEM.desc = nut.lang.Get("desc_wep_mp5k")