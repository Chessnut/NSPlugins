ITEM.name = "AR2 Cartridge"
ITEM.desc = "Box of 30 Bullets for AR2-type Guns."
ITEM.base = "base_ammo"
ITEM.uniqueID = "a_30_ar2"
ITEM.ammo = "ar2"
ITEM.amount = 30
ITEM.model = Model( "models/Items/combine_rifle_cartridge01.mdl" )