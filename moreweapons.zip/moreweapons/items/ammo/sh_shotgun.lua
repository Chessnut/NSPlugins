ITEM.name = "Buckshot Ammo"
ITEM.desc = "Box of 10 Bullets for SMG-type Guns."
ITEM.base = "base_ammo"
ITEM.uniqueID = "a_10_buckshot"
ITEM.ammo = "buckshot"
ITEM.amount = 10
ITEM.model = Model( "models/Items/BoxBuckshot.mdl" )