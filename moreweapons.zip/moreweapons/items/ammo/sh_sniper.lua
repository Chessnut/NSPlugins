ITEM.name = "Compact Pulse Cartridge"
ITEM.desc = "Box of 2 Bullets for Compact Pulse Cartridge Guns."
ITEM.base = "base_ammo"
ITEM.uniqueID = "a_2_snp"
ITEM.ammo = "SniperRound"
ITEM.amount = 2
ITEM.model = Model( "models/Items/combine_rifle_cartridge01.mdl" )