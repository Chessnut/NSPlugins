ITEM.name = "357 Ammo"
ITEM.desc = "Box of 30 Bullets for High-Calibur Guns."
ITEM.base = "base_ammo"
ITEM.uniqueID = "a_10_357"
ITEM.ammo = "357"
ITEM.amount = 10
ITEM.model = Model( "models/Items/357ammo.mdl" )