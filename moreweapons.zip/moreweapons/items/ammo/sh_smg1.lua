ITEM.name = "SMG Ammo"
ITEM.desc = "Box of 30 Bullets for SMG-type Guns."
ITEM.base = "base_ammo"
ITEM.uniqueID = "a_30_smg"
ITEM.ammo = "smg1"
ITEM.amount = 30
ITEM.model = Model( "models/Items/BoxMRounds.mdl" )