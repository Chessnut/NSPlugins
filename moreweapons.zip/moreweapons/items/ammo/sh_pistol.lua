ITEM.name = "Pistol Ammo"
ITEM.desc = "Box of 30 Bullets for Pistol-type Guns."
ITEM.base = "base_ammo"
ITEM.uniqueID = "a_30_pistol"
ITEM.ammo = "pistol"
ITEM.amount = 30
ITEM.model = Model( "models/Items/BoxSRounds.mdl" )