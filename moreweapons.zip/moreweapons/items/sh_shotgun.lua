ITEM.name = "Shotgun"
ITEM.base = "base_wep"
ITEM.uniqueID = "weapon_shotgun"
ITEM.category = nut.lang.Get("weapons_ranged")
ITEM.class = "weapon_shotgun"
ITEM.type = "primary"
ITEM.model = Model( "models/Weapons/w_shotgun.mdl" )
ITEM.desc = nut.lang.Get("desc_wep_shotty")