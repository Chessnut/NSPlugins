ITEM.name = ".357 Revolver"
ITEM.base = "base_wep"
ITEM.uniqueID = "hl2_357"
ITEM.category = nut.lang.Get("weapons_ranged")
ITEM.class = "hl2_r_357"
ITEM.type = "sidearm"
ITEM.model = Model( "models/Weapons/W_357.mdl" )
ITEM.desc = nut.lang.Get("desc_wep_357")