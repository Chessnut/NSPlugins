ITEM.name = "Bat"
ITEM.base = "base_wep"
ITEM.uniqueID = "hl2_m_bat"
ITEM.category = nut.lang.Get("weapons_melee")
ITEM.class = "hl2_m_bat"
ITEM.type = "melee"
ITEM.model = Model( "models/warz/melee/baseballbat.mdl" )
ITEM.desc = "A Bat"