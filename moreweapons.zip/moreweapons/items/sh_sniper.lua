ITEM.name = "Standard Issue Sniper Rifle"
ITEM.base = "base_wep"
ITEM.uniqueID = "hl2_sniper"
ITEM.category = nut.lang.Get("weapons_ranged")
ITEM.class = "hl2_r_sniper"
ITEM.type = "primary"
ITEM.model = Model( "models/Weapons/w_combinesniper_e2.mdl" )
ITEM.desc = nut.lang.Get("desc_wep_sniper")