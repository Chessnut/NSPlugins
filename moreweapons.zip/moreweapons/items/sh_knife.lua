ITEM.name = "Combat Knife"
ITEM.base = "base_wep"
ITEM.uniqueID = "hl2_m_knife"
ITEM.category = nut.lang.Get("weapons_melee")
ITEM.class = "hl2_m_knife"
ITEM.type = "melee"
ITEM.model = Model( "models/warz/melee/knife.mdl" )
ITEM.desc = "A Combat Knife"