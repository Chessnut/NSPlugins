ITEM.name = "Overwatch Issue Combine Pistol"
ITEM.base = "base_wep"
ITEM.uniqueID = "hl2_compist"
ITEM.category = nut.lang.Get("weapons_ranged")
ITEM.class = "hl2_r_compist"
ITEM.type = "sidearm"
ITEM.model = Model( "models/Weapons/w_cmbpis.mdl" )
ITEM.desc = "Overwatch Issue Combine Pistol."