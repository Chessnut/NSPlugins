ITEM.name = "9MM PISTOL"
ITEM.base = "base_wep"
ITEM.uniqueID = "hl2_pistol"
ITEM.category = nut.lang.Get("weapons_ranged")
ITEM.class = "hl2_r_pistol"
ITEM.type = "sidearm"
ITEM.model = Model( "models/Weapons/W_pistol.mdl" )
ITEM.desc = nut.lang.Get("desc_wep_9mm")