ITEM.base = "base_wep"
ITEM.name = "Crowbar"
ITEM.uniqueID = "hl2_m_crowbar"
ITEM.category = nut.lang.Get("weapons_melee")
ITEM.class = "hl2_m_crowbar"
ITEM.type = "melee"
ITEM.model = Model( "models/warz/melee/crowbar.mdl" )
ITEM.desc = "A Crowbar"