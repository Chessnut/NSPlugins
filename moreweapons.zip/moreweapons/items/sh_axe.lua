ITEM.name = "Axe"
ITEM.base = "base_wep"
ITEM.uniqueID = "hl2_m_axe"
ITEM.category = nut.lang.Get("weapons_melee")
ITEM.class = "hl2_m_axe"
ITEM.type = "melee"
ITEM.model = Model( "models/warz/melee/hatchet.mdl" )
ITEM.desc = "An Axe"