ITEM.name = "Carpenter Hammer"
ITEM.base = "base_wep"
ITEM.uniqueID = "hl2_m_hammer"
ITEM.category = nut.lang.Get("weapons_melee")
ITEM.class = "hl2_m_hammer"
ITEM.type = "melee"
ITEM.model = Model( "models/warz/melee/hammer.mdl" )
ITEM.desc = "A Carpenter Hammer"