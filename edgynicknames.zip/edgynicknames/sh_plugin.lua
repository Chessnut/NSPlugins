PLUGIN.name = "Edgy nicknames"
PLUGIN.author = "Ylsid"
PLUGIN.desc = "Not edgy enough? Get a nickname and fix that issue."

nut.util.Include("sh_commands.lua")