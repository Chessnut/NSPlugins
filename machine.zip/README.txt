!! The recycle machine has it's own junk system. !!
If you want to remove this plugin's junk system, just go to sh_plugin.lua and set 
PLUGIN.generateJunks = true 
to
PLUGIN.generateJunks = false
or delete that line.

All of machine is tested from custom schema. You have to set the machine's information by yourself!