PLUGIN.name = "Productive Machines"
PLUGIN.author = "Black Tea"
PLUGIN.desc = "If your server does not have proper economy? install this!"

function PLUGIN:LoadData()
	local restored = nut.util.ReadTable("machines")
	if (restored) then
		for k, v in pairs(restored) do
			local position = v.position
			local angles = v.angles
			local eclass  = v.class
			local entity = ents.Create(eclass)
			entity:SetPos(position)
			entity:SetAngles(angles)
			entity:Spawn()
			entity:Activate()
		end
	end
end

function PLUGIN:SaveData()
	local data = {}
	for k, v in pairs(ents.FindByClass("nut_m_*")) do
		print(v:GetClass())
		data[#data + 1] = {
			position = v:GetPos(),
			angles = v:GetAngles(),
			class = v:GetClass()
		}
	end
	nut.util.WriteTable("machines", data)
end
