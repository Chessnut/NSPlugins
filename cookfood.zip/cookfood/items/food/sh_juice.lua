ITEM.name = "Juice"
ITEM.uniqueID = "food_juice"
ITEM.model = Model("models/props_junk/garbage_glassbottle001a.mdl")
ITEM.desc = "Typical orange juice. Can be drink for %usenum|1% time(s)"
ITEM.hunger = 1
ITEM.thirst = 10
ITEM.data = {
	usenum = 4,
}
ITEM.cookable = false