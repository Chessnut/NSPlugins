ITEM.name = "Watermelon"
ITEM.uniqueID = "food_watermelon"
ITEM.model = Model("models/props_junk/watermelon01.mdl")
ITEM.hunger = 5
ITEM.thirst = 5
ITEM.data = {
	usenum = 10,
}
ITEM.desc = "Forgetful watermelon. Can be drink for %usenum|1% time(s)"