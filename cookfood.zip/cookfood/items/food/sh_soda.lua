ITEM.name = "Black Tea Soda"
ITEM.uniqueID = "food_btsoda"
ITEM.model = Model("models/props_junk/PopCan01a.mdl")
ITEM.desc = "Poppy, Crispy, Black Tea Soda."
ITEM.hunger = 1
ITEM.thirst = 10
ITEM.cookable = false