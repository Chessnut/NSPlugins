ITEM.name = "Soda Bottle"
ITEM.uniqueID = "food_soda_pb"
ITEM.model = Model("models/props_junk/garbage_plasticbottle003a.mdl")
ITEM.desc = "Poppy, Crispy, Black Tea Soda. Can be drink for %usenum|1% time(s)"
ITEM.hunger = 1
ITEM.thirst = 10
ITEM.data = {
	usenum = 3,
}
ITEM.cookable = false