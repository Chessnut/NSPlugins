ITEM.name = "Soda Bottle"
ITEM.uniqueID = "food_soda_pb"
ITEM.model = Model("models/props_junk/garbage_plasticbottle003a.mdl")
ITEM.desc = "Poppy, Crispy, Black Tea Soda."
ITEM.eatsound = "ambient/water/water_spray1.wav"
ITEM.eatpitch = 70
ITEM.hunger = 1
ITEM.thirst = 10
ITEM.data = {
	usenum = 3,
}
ITEM.cookable = false