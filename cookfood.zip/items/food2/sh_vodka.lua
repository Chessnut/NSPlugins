ITEM.name = "Vodka"
ITEM.uniqueID = "food_vodka"
ITEM.model = Model("models/props_junk/GlassBottle01a.mdl")
ITEM.desc = "Really cool vodka. Can be drink for %usenum|1% time(s)"
ITEM.hunger = 1
ITEM.thirst = 35
ITEM.data = {
	usenum = 2,
}
ITEM.cookable = false