ITEM.name = "Canned soup"
ITEM.uniqueID = "food_canned_1"
ITEM.model = Model("models/props_junk/garbage_metalcan001a.mdl")
ITEM.desc = "Canned soup. Contains soup for one person."
ITEM.hunger = 15
ITEM.thirst = 3
ITEM.cookable = false