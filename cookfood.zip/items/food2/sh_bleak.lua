ITEM.name = "Bleak"
ITEM.uniqueID = "food_bleak"
ITEM.model = Model("models/props_junk/garbage_plasticbottle001a.mdl")
ITEM.desc = "A Bleak there is a clock logo on the bottle. Can be drink for %usenum|1% time(s)"
ITEM.hunger = 0
ITEM.thirst = 0
ITEM.health = -10
ITEM.data = {
	usenum = 3,
}
ITEM.cookable = false