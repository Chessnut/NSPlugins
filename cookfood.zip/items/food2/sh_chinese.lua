ITEM.name = "Chinese Food"
ITEM.uniqueID = "food_chinese"
ITEM.model = Model("models/props_junk/garbage_takeoutcarton001a.mdl")
ITEM.desc = "You can eat this item. good ol' chinese box."