ITEM.name = "Milk Cartoon"
ITEM.uniqueID = "food_milk_c"
ITEM.model = Model("models/props_junk/garbage_milkcarton002a.mdl")
ITEM.desc = "A milk cartoon that not seems stored in good place."
ITEM.eatsound = "ambient/water/water_spray1.wav"
ITEM.eatpitch = 70
ITEM.hunger = 3
ITEM.thirst = 15
ITEM.data = {
	usenum = 3,
}
ITEM.cookable = false