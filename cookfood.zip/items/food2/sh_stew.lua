ITEM.name = "Stew"
ITEM.uniqueID = "food_stew"
ITEM.model = Model("models/props_c17/metalPot001a.mdl")
ITEM.desc = "Cooked stew. gives you calm feeling of warm."
ITEM.hunger = 30
ITEM.hungermultp = 5
ITEM.thirst = 20
ITEM.thirstmultp = 5
ITEM.data = {
	usenum = 8,
}
ITEM.cookable = true