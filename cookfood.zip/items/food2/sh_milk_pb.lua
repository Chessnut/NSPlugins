ITEM.name = "Milk Plastic Bottle"
ITEM.uniqueID = "food_milk_pb"
ITEM.model = Model("models/props_junk/garbage_milkcarton001a.mdl")
ITEM.desc = "A milk bottle that not seems stored in good place."
ITEM.eatsound = "ambient/water/water_spray1.wav"
ITEM.eatpitch = 70
ITEM.hunger = 3
ITEM.thirst = 15
ITEM.data = {
	usenum = 5,
}
ITEM.cookable = false