nut.lang.Add("cook_it", "%s cooks the %s")

nut.lang.Add("food_uncook", "not cooked.")
nut.lang.Add("food_worst", "utter shit.")
--nut.lang.Add("food_worst_it", "and the food has burnt seriously. Inside of the food is ruined and colored as black. But, It seems better than uncooked raw food.")
nut.lang.Add("food_reallybad", "black garbage.")
--nut.lang.Add("food_reallybad_it", "and the food has burnt. But Inside of the food is good to go.")
nut.lang.Add("food_bad", "visually burnt.")
--nut.lang.Add("food_bad_it", "and the food has burnt a bit. The food is colored as black a bit.")
nut.lang.Add("food_notgood", "over cooked.")
--nut.lang.Add("food_notgood_it", "over cooked.")
nut.lang.Add("food_normal", "cooked.")
--nut.lang.Add("food_normal_it", "cooked.")
nut.lang.Add("food_good", "cooked well.")
--nut.lang.Add("food_good_it", "cooked well.")
nut.lang.Add("food_sogood", "delicious.")
--nut.lang.Add("food_sogood_it", "delicious.")
nut.lang.Add("food_reallygood", "unbelieveable.")
--nut.lang.Add("food_reallygood_it", "unbelieveable.")
nut.lang.Add("food_best", "god-likely cooked.")
--nut.lang.Add("food_best_it", "god-likely cooked.")

nut.lang.Add("stove_desc", "Allows you to cook some food.")
nut.lang.Add("stove_name", "Cooking Stove.")

cookmod = {}
cookmod["notice_cooked"] = "You cooked %s."
cookmod["notice_turnonstove"] = "Failed Cooking: Stove must be active to cook %s."
cookmod["notice_notcookable"] = "Failed Cooking: %s Is not cookable."
cookmod["notice_alreadycooked"] = "Failed Cooking: %s is already cooked."
cookmod["notice_havetofacestove"] = "Failed Cooking: You have to face stove to cook %s."
--nut.lang.Get("desc_status")