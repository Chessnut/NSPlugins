nut.lang.Add("food_uncook", "not cooked.")
nut.lang.Add("food_worst", "utter shit.")
nut.lang.Add("food_reallybad", "black garbage.")
nut.lang.Add("food_bad", "visually burnt.")
nut.lang.Add("food_notgood", "over cooked.")
nut.lang.Add("food_normal", "cooked.")
nut.lang.Add("food_good", "cooked well.")
nut.lang.Add("food_sogood", "delicious.")
nut.lang.Add("food_reallygood", "unbelieveable.")
nut.lang.Add("food_best", "god-likely cooked.")

nut.lang.Add("stove_desc", "Allows you to cook some food.")
nut.lang.Add("stove_name", "Cooking Stove.")

cookmod = {}
cookmod["notice_cooked"] = "You cooked %s."
cookmod["notice_turnonstove"] = "Failed Cooking: Stove must be active to cook %s."
cookmod["notice_notcookable"] = "Failed Cooking: %s Is not cookable."
cookmod["notice_alreadycooked"] = "Failed Cooking: %s is already cooked."
cookmod["notice_havetofacestove"] = "Failed Cooking: You have to face stove to cook %s."
--nut.lang.Get("desc_status")