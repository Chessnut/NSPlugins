PLUGIN.name = "MOTD"
PLUGIN.author = "Black Tea"
PLUGIN.desc = "Allows you read motds."
nut.util.Include("sh_lang.lua")
nut.util.Include("sh_menu.lua")