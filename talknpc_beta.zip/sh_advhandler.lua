local PLUGIN = PLUGIN

/*---------------------------------------------------------
	This is advanced handler for dialogue plugin.
	You can make some quest like things with this.
	But I recommends you don't care about this handler
	If you don't know how to code. 
	
	I will not answer any question about how to use this plugin.
	Unless you have any clue about this dialogue handler.
--------------------------------------------------------*/


-- You can call SpecialCall with !.
-- example. when a player call dialouge that has uid "!quest_recieve_test" then it will call SpecialCall["quest_receive_test"].
PLUGIN.SpecialCall =
{
		["quest_receive_test"] = {
			sv = function( client, data ) 
			end,
			cl = function( client, panel, data ) end,
		},
		["quest_turnout_test"] = {
			sv = function( client, data ) end,
			cl = function( client, panel, data ) end,
		},
		["test"] = {
			sv = function( client, data )
				client:EmitSound( "items/smallmedkit1.wav" )
				client:SetHealth( 100 )
			end,
			cl = function( client, panel, data ) 
				panel:AddChat( data.name, "By the name of Black Tea! You're healed!" )
				panel.talking = false -- Ends the current conversation and allows player to talk about other topics.
			end,
		},
}

-- Handler.
if SERVER then
	netstream.Hook( "nut_DialogueMessage", function( client, data )
		if string.Left( 	data.request, 1 ) == "!" then
			data.request = string.sub( data.request, 2 )
			if PLUGIN.SpecialCall[ data.request ] then
				PLUGIN.SpecialCall[ data.request ].sv( client, data )
				netstream.Start( client, "nut_DialoguePingpong", data )
			else
				print( Format( "%s( %s ) tried to call invalid dialouge request( %s ) from %s.", client:Name(), client:Nick(), data.request, data.name ) )
				print( "Please check PLUGIN.SpecialCall or NPC's dialouge unique id." )
				client:EmitSound( "HL1/fvox/hev_general_fail.wav" )
			end
		end
	end)
else
	netstream.Hook( "nut_DialoguePingpong", function( data )
		if IsValid( nut.gui.dialogue ) then
			if PLUGIN.SpecialCall[ data.request ] then
				PLUGIN.SpecialCall[ data.request ].cl( client, nut.gui.dialogue, data )
			end
		end
	end)
end