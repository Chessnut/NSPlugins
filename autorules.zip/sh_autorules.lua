PLUGIN.name = "Black Tea Autorules"
PLUGIN.author = "Black Tea"
PLUGIN.desc = "RULES."
PLUGIN.maxhardkilling = 3

function PLUGIN:EntityTakeDamage(  target, dmginfo )
	local attacker = dmginfo:GetAttacker()
	if attacker:IsPlayer() and target:IsPlayer() then
		target.dmglog = target.dmglog or {}
		local dmg =  dmginfo:GetDamage()
		target.dmglog[ attacker ] = target.dmglog[ attacker ] or 0
		target.dmglog[ attacker ] = ( target.dmglog[ attacker ] + dmg )
	--	print( tostring( attacker ) .. " - " .. target.dmglog[ attacker ] )
	end
end

local whitelist = {
	FACTION_CP,
	FACTION_OVW,
	FACTION_REBEL1,
	FACTION_REBEL2,
}
function PLUGIN:PlayerDeath( ply, info, attacker )
	local tbllog = ply.dmglog or {} -- 죽임 당한 플레이어의 데미지 로그
	for att, amt in pairs( tbllog ) do
		if ( att == ply || !att:IsValid() ) then continue end
		 att.dmglog = att.dmglog  or {}
		local vicatt = att.dmglog[ ply ]  or 0 
		if ( amt  - vicatt ) > ply:GetMaxHealth() then
			
			if table.HasValue( whitelist, att:Team() ) then return end
			att.hardkilled = att.hardkilled or 0
			att.hardkilled = att.hardkilled + 1
			att:ChatPrint( "경고: 하드킬링을 하였습니다. 남은 횟수 " .. att.hardkilled .. " / " .. self.maxhardkilling ..". " )
			att:ChatPrint( "과도한 하드킬링은 서버에서 자동적으로 제재를 실시합니다." )
			if att.hardkilled >= 3 then att:Ban( 10, "하드킬링으로 인한 10분 밴" ) att:Kick( "과도한 하드킬링으로 인한 제재 - 10분 밴" ) end
			print( tostring( att:Name() ) .. " HARDKILLED " .. tostring( ply:Name() ) )
			
			att.dmglog[ ply ] = 0
			ply.dmglog = {}
			
		end
	end
end