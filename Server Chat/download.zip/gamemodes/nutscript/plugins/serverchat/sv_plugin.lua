local luasocket = require("luasocket")

if (PLUGIN.server) then
	PLUGIN.server:close()
end

local serverIP, serverPort = game.GetIP(), GetConVarString("hostport")
local serverAddress = serverIP..":"..serverPort

local ourServerPort
local ourServerPrefix

for k, v in pairs(PLUGIN.config.servers) do
	if (v[1]..":"..v[2] == serverAddress) then
		ourServerPort = v[3]
		ourServerPrefix = v[4]

		break
	end
end

if (!ourServerPort) then
	return ErrorNoHalt("Server is missing listening port!")
end

PLUGIN.server = socket.udp()
PLUGIN.server:setsockname(serverIP, ourServerPort)
PLUGIN.server:settimeout(0)

MsgN("[NutScript] Created server on "..serverIP..":"..ourServerPort)

if (PLUGIN.client) then
	PLUGIN.client:close()
end

PLUGIN.client = socket.udp()
PLUGIN.client:settimeout(0)

MsgN("[NutScript] Created client on "..serverIP..":"..PLUGIN.config.clientPort)

function PLUGIN:SendMessage(client, text)
	if (!IsValid(client)) then
		return
	end

	if (client:GetNutVar("nextGlobalChat", 0) < CurTime()) then
		client:SetNutVar("nextGlobalChat", CurTime() + self.config.delay)
	else
		return nut.util.Notify("You can not use global chat for "..math.floor(client:GetNutVar("nextGlobalChat") - CurTime()).." more second(s).", client)
	end

	text = text:sub(1, self.config.length)

	local realData = {
		self.config.token,
		client:Name(),
		string.FromColor(team.GetColor(client:Team())),
		ourServerPrefix or "??",
		text
	}
	local data = table.concat(realData, ";")

	for k, v in pairs(self.config.servers) do
		local address = v[1]..":"..v[2]

		if (address != serverAddress) then
			self.client:setpeername(v[1], v[3])
			self.client:send(data)
		end
	end

	table.remove(realData, 1)
	realData[2] = team.GetColor(client:Team())
	netstream.Start(nil, "nut_GlobalMessage", realData)
end

function PLUGIN:Tick()
	local data, message, port = self.server:receivefrom()

	if (data) then
		print(data)
		local token = data:sub(1, #self.config.token)
		data = string.Explode(";", data:sub(#self.config.token + 2))
		data[2] = string.ToColor(data[2])

		local name = data[1]
		local teamColor = data[2]
		local prefix = data[3]
		local text = data[4]

		if (name and teamColor and prefix and text) then
			text = text:sub(1, self.config.length)

			MsgC(Color(255, 0, 0), "["..prefix.."] ")
			MsgC(teamColor, name)
			MsgC(color_white, ": "..text.."\n")

			netstream.Start(nil, "nut_GlobalMessage", data)
		end
	end
end