PLUGIN.name = "Server Chat"
PLUGIN.author = "Chessnut"
PLUGIN.desc = "Allows players to communicate between servers."

-- The command for the global chat.
PLUGIN.command = "global"

-- http://facepunch.com/showthread.php?t=1332285&p=43136356&viewfull=1#post43136356
function game.GetIP()
	local hostip = GetConVarString("hostip") -- GetConVarNumber is inaccurate
	hostip = tonumber(hostip)

	local ip = {}
	ip[1] = bit.rshift(bit.band(hostip, 0xFF000000), 24)
	ip[2] = bit.rshift(bit.band(hostip, 0x00FF0000), 16)
	ip[3] = bit.rshift(bit.band(hostip, 0x0000FF00), 8)
	ip[4] = bit.band(hostip, 0x000000FF)

	return table.concat(ip, ".")
end

nut.util.Include("sv_config.lua")
nut.util.Include("sv_plugin.lua")

if (CLIENT) then
	local icon = Material("icon16/world.png")

	netstream.Hook("nut_GlobalMessage", function(data)
		chat.AddText(icon, Color(250, 40, 40), "["..data[3].."] ", data[2], data[1], color_white, ": "..data[4])
	end)
end

local PLUGIN = PLUGIN

nut.command.Register({
	syntax = "<string text>",
	allowDead = true,
	onRun = function(client, arguments)
		PLUGIN:SendMessage(client, table.concat(arguments, " "))
	end
}, PLUGIN.command)