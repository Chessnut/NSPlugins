PLUGIN.config = {}

-- How often a player may use server chat.
PLUGIN.config.delay = 1
-- The chat port for receiving chat messages.
PLUGIN.config.clientPort = 29015
-- The maximum length of chat messages.
PLUGIN.config.length = 64000
-- A secret token for cross server chat. Do not share it.
PLUGIN.config.token = "CHANGE ME"
-- The other servers that this server should communicate with.
-- Include this server in the list.
-- It goes: {server IP, server port, query port, prefix}
-- The query port MUST be different than each of the others.
PLUGIN.config.servers = {
	{"192.168.1.14", "27015", 29001, "#1"},
	{"192.168.1.14", "27016", 29002, "#2"}
}