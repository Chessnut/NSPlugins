DEFINE_BASECLASS("base_gmodentity");

ENT.Type = "anim";
ENT.Author = "robinkooli";
ENT.Category = "HL2 RP"
ENT.PrintName = "Combine Light";
ENT.Spawnable = true;
ENT.AdminSpawnable = true;