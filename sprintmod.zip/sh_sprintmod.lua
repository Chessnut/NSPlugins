PLUGIN.name = "Sprint Mod"
PLUGIN.author = "Black Tea"
PLUGIN.desc = "Modding sprint."

function PLUGIN:Move( ply, move )

		local fwd = move:GetForwardSpeed()
		local sid = move:GetSideSpeed()
		local side = .2
		local forward = 1
		if ply:KeyDown( IN_SPEED ) then
		
			if fwd>0 then
				local szx = -ply:GetMaxSpeed() * -forward

				if fwd>szx then
					move:SetForwardSpeed(szx)
				end		
			end
			
			if fwd<0 then			
				local szg = -ply:GetMaxSpeed() * forward
				
				if fwd<szg then
					move:SetForwardSpeed(szg)
				end
				
			end
			
			if sid>0 then		
				local sidszg = -ply:GetMaxSpeed() * -side
				
				if sid>sidszg then
					move:SetSideSpeed(sidszg)
				end			
			end
			
			if sid<0 then
				local sidszgh = -ply:GetMaxSpeed() * side
				
				if sid<sidszgh then
					move:SetSideSpeed(sidszgh)
				end
			end
		end
		
end