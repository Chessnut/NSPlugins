ITEM.name = "Air Filter"
ITEM.uniqueID = "air_filter"
ITEM.model = Model("models/Items/battery.mdl")
ITEM.desc = "An Air Filter. Can be used for the mask."
ITEM.usesound = "HL1/fvox/hiss.wav"
ITEM.weight = .1
