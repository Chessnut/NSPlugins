ITEM.name = "Wireframe Jeep"
ITEM.uniqueID = "vehicle_jeep"
ITEM.model = Model("models/buggy.mdl")
ITEM.vehiclescript = "scripts/vehicles/jeep_test.txt"
ITEM.desc = "Simple jeep. seems rusty and old. \nThis car's number is %number|not registed%"

ITEM.numplate = {
	{ pos = Vector( 0, -55, 35 ), ang = Angle( 180, 0, 90 ), scale = .2}
}
ITEM.seats =
{
	["passenger1" ] = { model = "models/nova/jeep_seat.mdl", pos = Vector( -38, 15, 19 ), ang = Angle( 0, 0, 0 ) },
	["passenger2" ] = { model = "models/nova/jeep_seat.mdl", pos = Vector( -110, 0, 20 ), ang = Angle( 0, 180, 0 ) },
}