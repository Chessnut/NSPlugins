PLUGIN.name = "Vehicles"
PLUGIN.author = "Black Tea"
PLUGIN.desc = "Get some vehicles for you!"
nut.util.Include("sh_lang.lua")
local playerMeta = FindMetaTable("Player")

function PLUGIN:PlayerDisconnected( player )
	for k, v in pairs( player:GetInventory() ) do
		for a, b in pairs( v ) do
			if b.data.onworld then
				b.data.onworld = nil
			end
		end
	end
	for k, v in pairs( ents.FindByClass( "prop_vehicle_jeep" ) ) do
		if v:GetNetVar( "owner" ) == player:EntIndex() then
			v:Remove()
		end
	end
end

function PLUGIN:Think()
	for k, v in pairs( player.GetAll() ) do
		if v:InVehicle() then
			local vehicle = v:GetVehicle()
			if vehicle:GetClass() == "prop_vehicle_jeep" then
				if vehicle.func_think then
					vehicle.func_think( v, vehicle )
				end
			end
		end
	end
end

function PLUGIN:PlayerUse( player, entity )
	if !player.nextEnterVehicle or player.nextEnterVehicle < CurTime() then
		if entity:GetClass() == "prop_vehicle_jeep" then
			if entity:GetDriver():IsValid() then
				for k, v in pairs( entity.seats ) do
					if !( v:GetDriver():IsValid() ) then
						player:EnterVehicle( v )
					end
				end
			end
		end
		player.nextEnterVehicle = CurTime() + 1
	end
end

function PLUGIN:PostDrawTranslucentRenderables( isDepth, isSkybox )
	for k, v in pairs( ents.FindByClass( "prop_vehicle_jeep" ) ) do
		local itemTable = nut.item.Get( v:GetNetVar( "item_uid" ) )
		if itemTable then
			if v:GetPos():Distance( LocalPlayer():GetPos() ) > 1000 then continue end
			for _, dat in pairs( itemTable.numplate ) do
				local pos = v:GetPos() + v:GetUp() * dat.pos.z + v:GetForward() * dat.pos.x + v:GetRight() * dat.pos.y
				local ang = v:GetAngles() 
				ang:RotateAroundAxis( v:GetRight(), dat.ang.pitch ) -- pitch
				ang:RotateAroundAxis( v:GetUp(),  dat.ang.yaw )-- yaw
				ang:RotateAroundAxis( v:GetForward(), dat.ang.roll )-- roll
				cam.Start3D2D( pos, ang, dat.scale)	
					surface.SetDrawColor( 0, 0, 0 )
					surface.SetTextColor( 255, 255, 255 )
					surface.SetFont( "ChatFont" )
					local size = { x = 10, y = 10 }
					size.x, size.y = surface.GetTextSize( v:GetNetVar( "number" ) )
					surface.SetTextPos( -size.x/2, -size.y/2 )
					size.x = size.x + 20; size.y = size.y + 10
					surface.DrawRect( -size.x/2, -size.y/2, size.x , size.y )
					surface.DrawText( v:GetNetVar( "number" ) )
				cam.End3D2D()
			end
		end
	end
end

function playerMeta:SpawnVehicle( itemTable, data, entity )
	
	local t = {}
	t.start = self:EyePos()
	t.endpos = t.start + self:GetAimVector() * 130
	t.filter = self
	local tr = util.TraceLine( t )
	
	local vehicle = ents.Create( "prop_vehicle_jeep" )
	vehicle:SetModel( itemTable.model )
	vehicle:SetKeyValue("vehiclescript", itemTable.vehiclescript ) 
	vehicle:SetPos( tr.HitPos )
	vehicle:Spawn()
	
	vehicle.seats = {}
	for name, dat in pairs( itemTable.seats ) do
		local seat = ents.Create( "prop_vehicle_prisoner_pod" )
		seat:SetModel( dat.model )
		seat:SetKeyValue("vehiclescript", "scripts/vehicles/prisoner_pod.txt" ) 
		seat:SetPos( vehicle:GetPos() + vehicle:GetUp() * dat.pos.z + vehicle:GetForward() * dat.pos.x + vehicle:GetRight() * dat.pos.y )
		local ang = vehicle:GetAngles() 
		ang:RotateAroundAxis( vehicle:GetRight(), dat.ang.pitch ) -- pitch
		ang:RotateAroundAxis( vehicle:GetUp(),  dat.ang.yaw )-- yaw
		ang:RotateAroundAxis( vehicle:GetForward(), dat.ang.roll )-- roll
		seat:SetAngle( ang )
		seat:Spawn()
		seat:Activate()
		seat:SetParent( vehicle )
		vehicle.seats[ name ] = seat
	end
	
	if itemTable.postSpawn then 
		itemTable.postSpawn( vehicle )
	end
	if itemTable.vehicleThink then
		vehicle.func_think = itemTable.vehicleThink
	end
	
	self:SetNetVar( "spawned_vehicle", vehicle:EntIndex() )
	vehicle:SetNetVar( "owner", self:EntIndex() )
	vehicle:SetNetVar( "number", data.number )
	vehicle:SetNetVar( "item_uid", itemTable.uniqueID )
	
	return vehicle
end

