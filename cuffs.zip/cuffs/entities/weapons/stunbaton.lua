if ( SERVER ) then
	AddCSLuaFile( "shared.lua" )
	SWEP.HoldType			= "crowbar"
end

if ( CLIENT ) then

	SWEP.PrintName			= "Stunbaton"			
	SWEP.Author				= "Black Tea"

	SWEP.Slot				= 1
	SWEP.SlotPos			= 7
	SWEP.ViewModelFOV		= 40
	SWEP.IconLetter			= "x"

end
-------------------------------------------------------------------

------------General Swep Info---------------
SWEP.Author   = "Black Tea?"
SWEP.Contact        = ""
SWEP.Purpose        = ""
SWEP.Instructions   = ""
SWEP.Spawnable      = true
SWEP.AdminSpawnable  = true
-----------------------------------------------

------------Models---------------------------
SWEP.ViewModel     = "models/weapons/v_stunstick.mdl"
SWEP.WorldModel    = "models/Weapons/w_stunbaton.mdl"
-----------------------------------------------

-------------Primary Fire Attributes----------------------------------------
SWEP.Primary.Delay			= .175	--In seconds
SWEP.Primary.Recoil			= 0		--Gun Kick
SWEP.Primary.Damage			= 45	--Damage per Bullet
SWEP.Primary.NumShots		= 1		--Number of shots per one fire
SWEP.Primary.Cone			= 0 	--Bullet Spread
SWEP.Primary.ClipSize		= -1	--Use "-1 if there are no clips"
SWEP.Primary.DefaultClip	= -1	--Number of shots in next clip
SWEP.Primary.Automatic   	= false	--Pistol fire (false) or SMG fire (true)
SWEP.Primary.Ammo         	= "none"	--Ammo Type
-------------End Primary Fire Attributes------------------------------------
 
-------------Secondary Fire Attributes-------------------------------------
SWEP.Secondary.Delay		= .09
SWEP.Secondary.Recoil		= 0
SWEP.Secondary.Damage		= 5
SWEP.Secondary.NumShots		= 1
SWEP.Secondary.Cone			= 0
SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic   	= false
SWEP.Secondary.Ammo         = "none"
-------------End Secondary Fire Attributes--------------------------------

-----------------------Main functions----------------------------
 
-- function SWEP:Reload() --To do when reloading
-- end 
 
function SWEP:Think() -- Called every frame

	if SERVER then
		if self.Owner:KeyDown( IN_ATTACK ) and self.Owner:KeyDown( IN_USE ) then
			if !self.timeToggle or self.timeToggle < CurTime() then
				self.Owner:SetWepRaised(!self.Owner:WepRaised())
				self.timeToggle = CurTime() + 1
				self.timeCooldown = CurTime() + .5
				return
			end
		end
	end
	
end

function SWEP:Initialize()
	util.PrecacheSound("physics/flesh/flesh_impact_bullet" .. math.random( 3, 5 ) .. ".wav")
	util.PrecacheSound("weapons/iceaxe/iceaxe_swing1.wav")
end
 
function SWEP:PrimaryAttack()
	self.Weapon:SetNextPrimaryFire(CurTime() + .6)
	local trace = self.Owner:GetEyeTrace()
	if trace.HitPos:Distance(self.Owner:GetShootPos()) <= 75 then
		self.Weapon:SendWeaponAnim(ACT_VM_HITCENTER)
		bullet = {}
		bullet.Num    = 1
		bullet.Src    = self.Owner:GetShootPos()
		bullet.Dir    = self.Owner:GetAimVector()
		bullet.Spread = Vector(0, 0, 0)
		bullet.Tracer = 0
		bullet.Force  = 1
		bullet.Damage = 0
		self.Owner:FireBullets(bullet) 
		self.Weapon:EmitSound("weapons/stunstick/stunstick_impact" .. math.random( 1,2 ) ..".wav")
		
		if trace.Entity:IsPlayer() then
			if SERVER then
			trace.Entity.intStack = trace.Entity.intStack or 0
			trace.Entity.intStack = ( trace.Entity.intStack + 1 ) or 1
			net.Start( "WhiteFlash" )
			net.Send( trace.Entity )
			trace.Entity:SetVelocity( self.Owner:GetAimVector() * 100 )
				if trace.Entity.intStack >= 3 then
					trace.Entity.intStack = 0
					trace.Entity:SetTimedRagdoll( 60, true )
				end
			end
		end
	else
		self.Weapon:EmitSound("weapons/iceaxe/iceaxe_swing1.wav")
		self.Weapon:SendWeaponAnim(ACT_VM_MISSCENTER)
	end
end
 
function SWEP:SecondaryAttack()
	return false
end
 

function SWEP:CanSecondaryAttack()
	return true
end