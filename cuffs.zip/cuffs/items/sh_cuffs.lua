ITEM.name = "Hand Cuffs"
ITEM.uniqueID = "handcuffs"
ITEM.model = Model("models/props_junk/cardboard_box004a.mdl")
ITEM.desc = "A pair of handcuffs that can hold the person's hands."

ITEM.functions = {}
ITEM.functions.Use = {
	alias = "Tie the person who you're looking at.",
	tip = "Use the item.",
	icon = "icon16/cog.png",
	run = function(itemTable, client, data, entity)
		if (SERVER) then
		
			local data = {}
				data.start = client:GetShootPos()
				data.endpos = data.start + client:GetAimVector() * 72
				data.filter = client
			local trace = util.TraceLine(data)
			local target
			
			if ( !trace.Entity || !trace.Entity:IsPlayer() ) then
				nut.util.Notify("Must look at correct target.", client)
			return false else target = trace.Entity end
			
			if client.character:GetVar( "tied" ) then
				nut.util.Notify("Target is already tied.", client)
			else
				client.character:SetVar( "tied", true )
			end
			
		end
		return true
	end
}
