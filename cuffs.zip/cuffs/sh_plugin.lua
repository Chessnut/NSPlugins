PLUGIN.name = "Handcuffs"
PLUGIN.author = "Black Tea"
PLUGIN.desc = "You get arrested sometimes."
PLUGIN.arr_spdmul = .2

function PLUGIN:PlayerBindPress( ply, bind, pressed )
	--To block more commands, you could add another line similar to
	--the one below, just replace the command
	if ply.character and ply.character:GetVar( "tied" ) then
		if ( string.find( bind, "use" ) ) then return false end
	end
end

if SERVER then
	util.AddNetworkString( "WhiteFlash" )
end
if CLIENT then
	local WhiteAlpha = 255
	function PLUGIN:HUDPaint()
		-- STUNBATON
			WhiteAlpha = Lerp( FrameTime()*3, WhiteAlpha, 0 )
			draw.RoundedBox( 0, 0, 0,ScrW(),ScrH(), Color( 255, 255, 255, WhiteAlpha ) )
	end
	net.Receive( "WhiteFlash", function()
		WhiteAlpha = 255
	end)
end

if SERVER then
	function PLUGIN:PlayerSpawn( player )
		if IsCombine( player ) then
			timer.Simple( .1, function()
				player:Give( "stunbaton" )
			end)
		end
	end
end

function PLUGIN:Move( ply, move )

		local fwd = move:GetForwardSpeed()
		local sid = move:GetSideSpeed()
		if ply:IsValid() and ply.character then
			if ply.character:GetVar( "tied" ) then
			
				if fwd>0 then
					local szx = -ply:GetMaxSpeed() * -self.arr_spdmul

					if fwd>szx then
						move:SetForwardSpeed(szx)
					end		
				end
				
				if fwd<0 then			
					local szg = -ply:GetMaxSpeed() * self.arr_spdmul
					
					if fwd<szg then
						move:SetForwardSpeed(szg)
					end
					
				end
				
				if sid>0 then		
					local sidszg = -ply:GetMaxSpeed() * -self.arr_spdmul
					
					if sid>sidszg then
						move:SetSideSpeed(sidszg)
					end			
				end
				
				if sid<0 then
					local sidszgh = -ply:GetMaxSpeed() * self.arr_spdmul
					
					if sid<sidszgh then
						move:SetSideSpeed(sidszgh)
					end
				end
			end
		end	
		
end