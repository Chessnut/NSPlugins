PLUGIN.name = "Bank Robbery"
PLUGIN.author = "Johnny Guitar"
PLUGIN.desc = "Rob banks, Payday 2 style mothafucka"