PLUGIN.name = "Vorti-Howl"
PLUGIN.author = "josephfra. Inspired by Teh Flamin' Taco"
PLUGIN.desc = "Howling for Vorts!"

if CLIENT then
	surface.CreateFont("nut_C_Yell", {
		font = mainFont,
		size = 24,
		weight = 1000,
		antialias = true
	})
end

nut.chat.Register("howl", {
	onChat = function(speaker, text)
		if (speaker:Team() == FACTION_VORT) then
			chat.AddText(Color(77, 158, 154), nut.schema.Call("GetPlayerName", speaker, "howl", text).." howls: "..text)
			surface.PlaySound( "vo/outland_01/intro/ol01_vortcall0"..math.random(1, 4)..".wav" or "vo/outland_01/intro/ol01_vortresp01.wav" or "vo/outland_01/intro/ol01_vortresp04.wav" )
			else
			chat.AddText(Color(77, 158, 154), "A vortigaunt howls")
			surface.PlaySound( "vo/outland_01/intro/ol01_vortcall0"..math.random(1, 4)..".wav" or "vo/outland_01/intro/ol01_vortresp01.wav" or "vo/outland_01/intro/ol01_vortresp04.wav" )
		end
	end,
	canSay = function(speaker)
		if not (speaker:Team() == FACTION_VORT) then
			nut.util.Notify(nut.lang.Get("no_perm", speaker:Name()), speaker)

			return
		end

		return true
	end,
	font = "nut_C_Yell",
	prefix = "/howl"
})