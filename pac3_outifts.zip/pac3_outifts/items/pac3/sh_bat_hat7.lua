ITEM.name = "X-Mas Santa Hat"
ITEM.uniqueID = "hat_xmas"
ITEM.desc = "What?"
ITEM.part = "e_head"
ITEM.outfit = ITEM.uniqueID