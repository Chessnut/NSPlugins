ITEM.name = "Large Bag"
ITEM.uniqueID = "eq_bag2"
ITEM.desc = "Well-used Large Bag."
ITEM.part = "e_back"
ITEM.outfit = ITEM.uniqueID