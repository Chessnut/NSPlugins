ITEM.name = "Hat"
ITEM.uniqueID = "hat_chang"
ITEM.desc = "A Hat"
ITEM.part = "e_head"
ITEM.outfit = ITEM.uniqueID