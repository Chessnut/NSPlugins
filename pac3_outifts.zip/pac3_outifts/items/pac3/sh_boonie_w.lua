ITEM.name = "Woodland Boonie Hat"
ITEM.uniqueID = "hat_woodboonie"
ITEM.desc = "Old Boonie Hat."
ITEM.part = "e_head"
ITEM.outfit = ITEM.uniqueID