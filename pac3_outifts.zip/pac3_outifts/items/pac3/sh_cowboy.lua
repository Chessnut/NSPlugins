ITEM.name = "Cowboy Hat"
ITEM.uniqueID = "hat_cowboy"
ITEM.desc = "Good-old Leathered Boonie Hat"
ITEM.part = "e_head"
ITEM.outfit = ITEM.uniqueID