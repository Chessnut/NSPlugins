ITEM.name = "Gas Mask"
ITEM.uniqueID = "hat_mask2"
ITEM.desc = "A Gas Mask that prevents you from bad-airs"
ITEM.part = "e_head"
ITEM.outfit = ITEM.uniqueID