ITEM.name = "Headphone Attached Hat"
ITEM.uniqueID = "hat_radio"
ITEM.desc = "Makes your eaiser to hear any kind of transmission."
ITEM.part = "e_head"
ITEM.outfit = ITEM.uniqueID