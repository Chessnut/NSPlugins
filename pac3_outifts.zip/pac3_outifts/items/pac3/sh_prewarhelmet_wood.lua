ITEM.name = "Pre-War Helmet"
ITEM.uniqueID = "hat_prewarhelmet_wood"
ITEM.desc = "A Bullet-proof Helmet that used to be worn in Pre-war session."
ITEM.part = "e_head"
ITEM.outfit = ITEM.uniqueID