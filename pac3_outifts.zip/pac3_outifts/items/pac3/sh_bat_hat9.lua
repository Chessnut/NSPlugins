ITEM.name = "Beanie Hat"
ITEM.uniqueID = "hat_beanie"
ITEM.desc = "Fancy hat. Good to not lose your heats"
ITEM.part = "e_head"
ITEM.outfit = ITEM.uniqueID