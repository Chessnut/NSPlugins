ITEM.name = "Fur Hat"
ITEM.uniqueID = "hat_rus"
ITEM.desc = "Furs in hat makes you more hotter than before."
ITEM.part = "e_head"
ITEM.outfit = ITEM.uniqueID