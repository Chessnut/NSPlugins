ITEM.name = "Beret Hat"
ITEM.uniqueID = "hat_beret2"
ITEM.desc = "Beret Hat. Makes your more sharp and edgy."
ITEM.part = "e_head"
ITEM.outfit = ITEM.uniqueID