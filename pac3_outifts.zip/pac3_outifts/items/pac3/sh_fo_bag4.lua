ITEM.name = "Backpack"
ITEM.uniqueID = "fo_bag1"
ITEM.desc = "A Backpack with useful gears."
ITEM.part = "e_back"
ITEM.outfit = ITEM.uniqueID