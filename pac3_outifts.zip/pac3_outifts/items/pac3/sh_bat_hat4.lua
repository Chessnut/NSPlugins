ITEM.name = "Headphone Attached Boonie Hat"
ITEM.uniqueID = "hat_radio_boonie"
ITEM.desc = "Makes your eaiser to hear any kind of transmission."
ITEM.part = "e_head"
ITEM.outfit = ITEM.uniqueID