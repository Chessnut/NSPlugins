ITEM.name = "Headphone Attached Fur Hat"
ITEM.uniqueID = "hat_radio_rus"
ITEM.desc = "Makes your eaiser to hear any kind of transmission."
ITEM.part = "e_head"
ITEM.outfit = ITEM.uniqueID