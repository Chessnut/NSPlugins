ITEM.name = "Desert Boonie Hat"
ITEM.uniqueID = "hat_desertboonie"
ITEM.desc = "Old Boonie Hat."
ITEM.part = "e_head"
ITEM.outfit = ITEM.uniqueID