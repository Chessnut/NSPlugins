ITEM.name = "Bag"
ITEM.uniqueID = "eq_bag"
ITEM.desc = "Well-used Bag."
ITEM.part = "e_back"
ITEM.outfit = ITEM.uniqueID