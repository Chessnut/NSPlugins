ITEM.name = "Shemagh"
ITEM.uniqueID = "hat_shem"
ITEM.desc = "A Cloth that covers your face."
ITEM.part = "e_head"
ITEM.outfit = ITEM.uniqueID