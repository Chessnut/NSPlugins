nut.lang.Add("food_uncook", "not cooked.")
--nut.lang.Get("desc_status")