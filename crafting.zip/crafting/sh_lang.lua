nut.lang.Add("crafting", "Crafting")
nut.lang.Add("needmoremats", "You need more materials to craft %s.")
nut.lang.Add("donecrafting", "You have crafted %s.")
nut.lang.Add("icat_material", "Materials")

nut.lang.Add("crft_text", "Crafting %s\n%s\n\nRequirements:\n")