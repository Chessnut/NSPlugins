ITEM.name = "Motolov"
ITEM.uniqueID = "motolov"
ITEM.category = "Consumable Weapons"
ITEM.model = Model( "models/props_junk/GlassBottle01a.mdl" )
ITEM.desc = "A Bottle of motolov cocktail"