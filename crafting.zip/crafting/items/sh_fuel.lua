ITEM.name = "Fuel"
ITEM.uniqueID = "fuel"
ITEM.category = nut.lang.Get( "icat_material" )
ITEM.model = Model( "models/props_junk/gascan001a.mdl" )
ITEM.desc = "A Can of fuel"