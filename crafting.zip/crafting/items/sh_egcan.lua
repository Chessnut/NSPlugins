ITEM.name = "Empty Fuel Can"
ITEM.uniqueID = "egcan"
ITEM.category = nut.lang.Get( "icat_material" )
ITEM.model = Model( "models/props_junk/metalgascan.mdl" )
ITEM.desc = "An Empty Fuel Can."