ITEM.name = "Empty Bottle"
ITEM.uniqueID = "emptybottle"
ITEM.category = nut.lang.Get( "icat_material" )
ITEM.model = Model( "models/props_junk/GlassBottle01a.mdl" )
ITEM.desc = "A Empty bottle"