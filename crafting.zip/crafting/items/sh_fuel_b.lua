ITEM.name = "Bottle of Gasoline"
ITEM.uniqueID = "bgas"
ITEM.category = nut.lang.Get( "icat_material" )
ITEM.model = Model( "models/props_junk/glassjug01.mdl" )
ITEM.desc = "A Bottle of fuel"