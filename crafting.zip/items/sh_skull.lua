ITEM.name = "A Skull"
ITEM.category = nut.lang.Get( "icat_material" )
ITEM.model = Model( "models/Gibs/HGIBS.mdl" )
ITEM.desc = "A Skull. Good to be creepy."