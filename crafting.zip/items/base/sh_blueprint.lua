BASE.name = "Base Blueprint"
BASE.weight = 0
BASE.category = "Blueprints"
BASE.model = "models/props_lab/clipboard.mdl"