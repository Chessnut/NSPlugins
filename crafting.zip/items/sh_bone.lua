ITEM.name = "A Bone"
ITEM.category = nut.lang.Get( "icat_material" )
ITEM.model = Model( "models/Gibs/HGIBS_spine.mdl" )
ITEM.desc = "A Material that can be used to craft Skull."