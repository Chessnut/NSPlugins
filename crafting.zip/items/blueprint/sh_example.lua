ITEM.name = "Blueprint - Skull"
ITEM.desc = "A blueprint that contains the method to make skull."