PLUGIN.name = "More Foods"
PLUGIN.author = "Black Tea"
PLUGIN.desc = "morefoods."
