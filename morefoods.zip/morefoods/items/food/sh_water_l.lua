ITEM.name = "Water"
ITEM.uniqueID = "food_water_l"
ITEM.model = Model("models/warz/consumables/water_l.mdl")
ITEM.desc = "A Large water bottle. Can be drink for %usenum|1% time(s)"
ITEM.hunger = 1
ITEM.thirst = 10
ITEM.data = {
	usenum = 4,
}
ITEM.cookable = false