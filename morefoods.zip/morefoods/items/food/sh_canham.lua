ITEM.name = "Canned Ham"
ITEM.uniqueID = "food_canham"
ITEM.model = Model("models/warz/consumables/can_spam.mdl")
ITEM.desc = "Canned ham. Contains ham for one person."
ITEM.hunger = 40
ITEM.thirst = 3
ITEM.cookable = false