ITEM.name = "Granola Bar"
ITEM.uniqueID = "food_granola"
ITEM.model = Model("models/warz/consumables/bar_granola.mdl")
ITEM.desc = "A Bar that can be good source of the energy."
ITEM.hunger = 30
ITEM.cookable = false