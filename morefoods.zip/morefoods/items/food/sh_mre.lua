ITEM.name = "MRE"
ITEM.uniqueID = "food_mre"
ITEM.model = Model("models/warz/consumables/bag_mre.mdl")
ITEM.desc = "Contains large amount of food. Can be eaten for %usenum|1% time(s)"
ITEM.hunger = 50
ITEM.data = {
	usenum = 3,
}
ITEM.cookable = false