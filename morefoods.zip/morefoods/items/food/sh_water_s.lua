ITEM.name = "Water"
ITEM.uniqueID = "food_water_s"
ITEM.model = Model("models/warz/consumables/water_s.mdl")
ITEM.desc = "A Water bottle."
ITEM.hunger = 1
ITEM.thirst = 10
ITEM.cookable = false