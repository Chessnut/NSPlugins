ITEM.name = "Energy Drink"
ITEM.uniqueID = "food_edrink"
ITEM.model = Model("models/warz/consumables/energy_drink.mdl")
ITEM.desc = "Energy Drink. Gives you enough energy to run!"
ITEM.hunger = 20
ITEM.thirst = 100
ITEM.cookable = false