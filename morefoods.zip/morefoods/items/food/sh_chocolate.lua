ITEM.name = "Chocolate Bar"
ITEM.uniqueID = "food_chocolate"
ITEM.model = Model("models/warz/consumables/bar_chocolate.mdl")
ITEM.desc = "Chocolate bar."
ITEM.hunger = 15
ITEM.thirst = 3
ITEM.data = {
	usenum = 2,
}
ITEM.cookable = false