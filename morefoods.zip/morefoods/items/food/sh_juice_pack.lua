ITEM.name = "Juice Pack"
ITEM.uniqueID = "food_juice_pack"
ITEM.model = Model("models/warz/consumables/juice.mdl")
ITEM.desc = "A Juice Pack"
ITEM.hunger = 0
ITEM.thirst = 20
ITEM.cookable = false