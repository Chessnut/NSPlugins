ITEM.name = "Potato Chip"
ITEM.uniqueID = "food_potatochip"
ITEM.model = Model("models/warz/consumables/bag_chips.mdl")
ITEM.desc = "A Bag of Potato Chip. Contains chips for one person."
ITEM.hunger = 20
ITEM.thirst = 0
ITEM.cookable = false