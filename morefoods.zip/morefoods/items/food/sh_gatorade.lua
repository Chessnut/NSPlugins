ITEM.name = "Gatorade"
ITEM.uniqueID = "food_gato"
ITEM.model = Model("models/warz/consumables/gatorade.mdl")
ITEM.hunger = 0
ITEM.thirst = 50
ITEM.desc = "GATORATE. What do i have to explain?"