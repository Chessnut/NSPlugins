PLUGIN.name = "Black Tea Tweaks"
PLUGIN.author = "Black Tea"
PLUGIN.desc = "Modding sprint."

local ragtime = CurTime()
local ragnext = 600

if CLIENT then
	function PLUGIN:RagdollCleanUp()
		for k,v in pairs(ents.FindByClass('class C_ClientRagdoll')) do v:Remove() end
	end
else

end

function PLUGIN:Think()
	if CLIENT then
		if ragtime < CurTime() then
			self:RagdollCleanUp()
			ragtime = CurTime() + ragnext
		end
	end
end

function PLUGIN:Footstep( ply, pos, foot, sound, volume, filter )
	print( ply )
	return true
end