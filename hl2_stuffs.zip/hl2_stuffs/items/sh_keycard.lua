ITEM.name = "Combine Keycard"
ITEM.uniqueID = "comkey"
ITEM.model = Model("models/gibs/metal_gib4.mdl")
ITEM.desc = "A Combine Key Card that allows you to access some combine-only areas."