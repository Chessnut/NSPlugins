PLUGIN.name = "Currency Printers"
PLUGIN.author = "Black Tea"
PLUGIN.desc = "If your server does not have proper economy? install this!"