PLUGIN.buffs[ "painful" ] = {
	name = "Painful Pains",
	desc = "You're in pain because you're ass man",
	func = function( player, name, level, mul )
		player.timeNextPain = player.timeNextPain or CurTime()
		if player.timeNextPain < CurTime() then
			player:EmitSound( Format( "vo/npc/male01/pain0%d.wav", math.random( 1, 9 ) ) )
			player:TakeDamage( 2 )
			player.timeNextPain = CurTime() + 1
		end
	end,
}

PLUGIN.buffs[ "heal_instant" ] = {
	name = "Instant Heal",
	desc = "You Get Healed",
	nodisp = true,
	func = function( player, name, level, mul )
		local medlvl = player:GetAttrib( ATTRIB_MEDICAL )
		player:EmitSound( "items/medshot4.wav" )
		player:SetHealth( math.Clamp( player:Health() + level + medlvl*mul, 0, player:GetMaxHealth() ) )
		player:RemoveBuff( name )
	end,
}

PLUGIN.buffs[ "dehydrated" ] = {
	name = "Dehydrated",
	desc = "You're dehydrated.",
	func = function( player, name, level, mul )
		player.timeNextDehydrated = player.timeNextDehydrated or CurTime()
		if player.timeNextDehydrated < CurTime() then
			player:EmitSound( Format( "ambient/voices/cough%d.wav", math.random( 1, 4 ) ) )
			player:ConCommand( "say /me coughs." )
			player.timeNextCough = CurTime() + 5
		end
	end,
} 

PLUGIN.buffs[ "starving" ] = {
	name = "Starving",
	desc = "You're starving.",
	func = function( player, name, level, mul )
		player.timeNextHungry = player.timeNextHungry or CurTime()
		if player.timeNextHungry < CurTime() then
			player:EmitSound( Format( "ambient/voices/cough%d.wav", math.random( 1, 4 ) ) )
			player:ConCommand( "say /me coughs." )
			player.timeNextCough = CurTime() + 5
		end
	end,
}

PLUGIN.buffs[ "posion" ] = {
	name = "Poisoned",
	desc = "You're Poisoned.",
	func = function( player, name, level, mul )
		player.timeNextCough = player.timeNextCough or CurTime()
		player.timeNextStamina = player.timeNextStamina or CurTime()
		if player.timeNextCough < CurTime() then
			player:EmitSound( Format( "ambient/voices/cough%d.wav", math.random( 1, 4 ) ) )
			player:ConCommand( "say /me coughs." )
			player.timeNextCough = CurTime() + 10
		end
		if player.timeNextStamina < CurTime() then
			local stam = player.character:GetVar( "stamina" )
			player.character:SetVar( "stamina", stam - 20 )
			player.timeNextStamina = CurTime() + 5
		end
	end,
} 

PLUGIN.buffs[ "neurotoxin" ] = {
	name = "Neuro Toxin",
	desc = "You're Poisoned.",
	func = function( player, name, level, mul )
		player:Freeze( true )
		timer.Simple( level, function()
			if player:IsValid() then
				player:Freeze( false )
			end
		end)
		player:RemoveBuff( name )
	end,
} 

PLUGIN.buffs[ "inf1" ] = {
	name = "Minor Infestation",
	desc = "You're Infested.",
	func = function( player, name, level, mul )
		player.timeNextCough = player.timeNextCough or CurTime()
		player.timeNextSay = player.timeNextSay or CurTime()
		if player.timeNextCough < CurTime() then
			player:EmitSound( Format( "ambient/voices/cough%d.wav", math.random( 1, 4 ) ) )
			player:ConCommand( "say /me coughs." )
			player.timeNextCough = CurTime() + 5
		end
		if player.timeNextSay < CurTime() then
			player:ConCommand( "say /me breezes the body." )
			player.timeNextSay = CurTime() + 18
		end
	end,
} -- WARNING IF YOU'RE CHANING YOUR CHARACTER OR LEAVE THE SERVER CHARACTER WILL BE REMOVED.

PLUGIN.buffs[ "inf2" ] = {
	name = "Medium Infestation",
	desc = "You're Infested.",
	func = function( player, name, level, mul )
	end,
} -- WARNING IF YOU'RE CHANING YOUR CHARACTER OR LEAVE THE SERVER CHARACTER WILL BE REMOVED.

PLUGIN.buffs[ "inf3" ] = {
	name = "High Infestation",
	desc = "You're Infested.",
	func = function( player, name, level, mul )
	end,
} -- WARNING IF YOU'RE CHANING YOUR CHARACTER OR LEAVE THE SERVER CHARACTER WILL BE REMOVED.

PLUGIN.buffs[ "inf4" ] = {
	name = "Critical Infestation",
	desc = "You're Infested.",
	func = function( player, name, level, mul )
	end,
} -- WARNING IF YOU'RE CHANING YOUR CHARACTER OR LEAVE THE SERVER CHARACTER WILL BE REMOVED.