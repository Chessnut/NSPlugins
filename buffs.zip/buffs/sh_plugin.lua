PLUGIN.name = "Buffs and Debuffs"
PLUGIN.author = "Black Tea"
PLUGIN.desc = "Sometimes, You get sick or high."
PLUGIN.buffs = {}
nut.util.Include("sh_lang.lua")
nut.util.Include("sh_buffs.lua")

ATTRIB_MEDICAL = nut.attribs.SetUp(nut.lang.Get("stat_medical"), nut.lang.Get("stat_medical_desc"), "medic")

if (SERVER) then

	local playerMeta = FindMetaTable("Player")
	
	function playerMeta:AddBuff( strBuff, intDuration, intLevel, intMultiply ) -- perma
		local tblBuffs = self:GetNetVar( "buffs" ) or {}
			tblBuffs[ strBuff ] = { CurTime() + intDuration, intLevel, intMultiply }
			hook.Call( "OnBuffed", GAMEMODE, strBuff, intDuration, intLevel )
		self:SetNetVar( "buffs", tblBuffs )
	end
	
	function playerMeta:RemoveBuff( strBuff ) -- perma
		local tblBuffs = self:GetNetVar( "buffs" ) or {}
			tblBuffs[ strBuff ] = nil
		self:SetNetVar( "buffs", tblBuffs )
	end
	
	function PLUGIN:PlayerSpawn( player )
		player:SetNetVar( "buffs", nil )
	end
	
	function PLUGIN:Think()
		for k, v in pairs ( player.GetAll() ) do
			if !( v:IsValid() and v:Alive() ) then continue end 
			local tblBuffs = v:GetNetVar( "buffs" ) or {}
			for name, dat in pairs( tblBuffs ) do
				local tblBuffInfo = self.buffs[ name ]
				if tblBuffInfo then
					tblBuffInfo.func( v, name, dat[2], dat[3] )
				end
				if dat[1] < CurTime() then
					v:RemoveBuff( name )
				end
			end
		end
	end
	
end
