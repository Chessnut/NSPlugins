nut.lang.Add("stat_medical", "의료")
nut.lang.Add("stat_medical_desc", "당신의 의료 기술이 얼마나 좋은지 결정합니다.")
--nut.lang.Get("desc_status")