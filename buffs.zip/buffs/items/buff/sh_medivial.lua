ITEM.name = "의료 도구"
ITEM.uniqueID = "buff_medickit"
ITEM.model = Model("models/Items/HealthKit.mdl")
ITEM.desc = "의료 목적의 소형 액체 주입 기구."

ITEM.addbuff = {
	{ "heal_instant", 1, 50, 5 }
}