ITEM.name = "신경 독침"
ITEM.uniqueID = "buff_neuro"
ITEM.model = Model("models/Items/CrossbowRounds.mdl")
ITEM.desc = "신경 독이 발라진 치명적인 바늘. 대상을 40초동안 마비시킬 수 있다."

ITEM.addbuff = {
	{ "neurotoxin", 1, 40, 0 }
}