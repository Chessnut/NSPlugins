ITEM.name = "Pain Pills"
ITEM.uniqueID = "buff_pills"
ITEM.model = Model("models/props_lab/jar01b.mdl")
ITEM.desc = "PAIN PILL"

ITEM.addbuff = {
	{ "heal_instant", 30, 30, 2 }
}