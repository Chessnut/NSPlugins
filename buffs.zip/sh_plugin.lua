local PLUGIN = PLUGIN
local playerMeta = FindMetaTable("Player")

PLUGIN.name = "Buffs and Debuffs"
PLUGIN.author = "Black Tea"
PLUGIN.desc = "Sometimes, You get sick or high."
PLUGIN.buffs = {}

PLUGIN.Hunger = true
bool_HungerRandomQuotes = true
PLUGIN.FallLegBreak = true -- Enables leg break on high speed collision on the ground.

nut.util.Include("sh_buffs.lua")
nut.util.Include("sh_buffhooks.lua")
nut.util.Include("sh_lang.lua")

ATTRIB_MEDICAL = nut.attribs.SetUp(nut.lang.Get("stat_medical"), nut.lang.Get("stat_medical_desc"), "medic")


-- getBuff( string [Buff's unique name] )
-- returns table
-- This function gets buff's data.
function getBuff( name )
	return PLUGIN.buffs[ name ]
end

-- player:GetBuffs()
-- returns table
-- This function gets one's all buffs.
function playerMeta:GetBuffs()
	return self:GetNetVar( "buffs" ) or {}
end

-- player:AddBuff( string [Buff's unique name] )
-- returns table or boolean( false )
-- This function allows you handle buffs
function playerMeta:HasBuff( strBuff )
	if self:GetNetVar( "buffs" ) != nil then
		return ( self:GetNetVar( "buffs" )[ strBuff ] )
	else
		return false
	end
end

if (SERVER) then

	-- player:AddBuff( string [Buff's unique name], integer [Buff's Duration Time], table [Parameters] )
	-- This function allows you to add some buffs to player.
	function playerMeta:AddBuff( strBuff, intDuration, parameter ) 
		if !intDuration then intDuration = math.huge end
		local tblBuffs = self:GetNetVar( "buffs" ) or {}
			local tblBuffInfo = getBuff( strBuff )
			if tblBuffInfo and tblBuffInfo.onbuffed then
				if !self:HasBuff( strBuff ) then
					tblBuffInfo.onbuffed( self, parameter )
				end
			end
			tblBuffs[ strBuff ] = { CurTime() + intDuration, parameter }
			hook.Call( "OnBuffed", GAMEMODE, strBuff, intDuration, parameter )
		self:SetNetVar( "buffs", tblBuffs )
	end
	
	-- player:RemoveBuff( string [Buff's unique name], table [Parameters] )
	-- This function allows you to add some buffs to player.
	function playerMeta:RemoveBuff( strBuff, parameter ) -- perma
		local tblBuffs = self:GetNetVar( "buffs" ) or {}
			local tblBuffInfo = getBuff( strBuff )
			if tblBuffInfo and tblBuffInfo.ondebuffed then
				tblBuffInfo.ondebuffed( self, parameter )
			end
			tblBuffs[ strBuff ] = nil
		self:SetNetVar( "buffs", tblBuffs )
	end
	
	-- player:PlayerSpawn( player player )
	-- This hook wipes every buffs on your character.
	-- I suggest you do not touch this function unless you know what you're doing.
	function PLUGIN:PlayerSpawn( player )
		player:SetNetVar( "buffs", {} )
	end

	-- player:Think( )
	-- This hook handles every player's buff effect.
	-- I suggest you do not touch this function unless you know what you're doing.
	function PLUGIN:Think()
		for k, v in pairs ( player.GetAll() ) do
			if !( v:IsValid() and v:Alive() ) then continue end 
			local tblBuffs = v:GetNetVar( "buffs" ) or {}
			for name, dat in pairs( tblBuffs ) do
				local tblBuffInfo = self.buffs[ name ]
				if tblBuffInfo and tblBuffInfo.func then
					tblBuffInfo.func( v, dat[2] )
				end
				if dat[1] < CurTime() then
					v:RemoveBuff( name )
				end
			end
		end
	end
		
end