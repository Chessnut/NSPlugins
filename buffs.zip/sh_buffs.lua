/*
	PLUGIN.buffs[ << string, Buff's Unique Name>> ] = { -- This is the unique name for identifying the buff.
		name =<< string, Buff's Display Name>>, -- This is the display name of the buff. 
		desc = << string, Buff's Description>>, -- This is the description of this buff.
		nodisp = << boolean, Buff's Display Factor >>, -- This is the factor for displaying this buff. ( For advaced scripters )
		func = << function, Buff's Think Function >>,
		onbuffed = << function, Buff's Function that executes on buffed >>, 
		onunbuffed = << function, Buff's Function that executes on Unbuffed >>, 
	}
*/

PLUGIN.buffs[ "heal" ] = {
	name = "Instant Heal",
	desc = "You Get Healed",
	nodisp = true, -- NO DISPLAY ( FOR HUDS )
	func = function( player, parameter)
		local medlvl = player:GetAttrib( ATTRIB_MEDICAL ) or 0
		local mul = parameter.skillmultiply or 0
		player:EmitSound( "items/medshot4.wav" )
		player:SetHealth( math.Clamp( player:Health() + parameter.amount + mul * medlvl, 0, player:GetMaxHealth() ) )
		player:RemoveBuff( "heal" )
	end,
}

PLUGIN.buffs[ "sample_jumpy" ] = {
	name = "Random Jump",
	desc = "YOU'RE ADDICTED TO JUMP.",
	onbuffed = function( player, parameter )
		player:ChatPrint( "YOU'RE ADDICTED TO JUMP." )
	end,
	func = function( player, parameter)
		player.timeNextJump = player.timeNextJump or CurTime()
		if player.timeNextJump < CurTime() then
			if player:OnGround() then
				player:SetVelocity( Vector( 0, 0, 250 ) )
				player.timeNextJump = CurTime() + .5
			end
		end
	end,
} 

PLUGIN.buffs[ "leghurt" ] = {
	name = "Leg Injury",
	desc = "Your legs are injured and your movement has been handicapped.",
	onbuffed = function( player, parameter )
		player:ChatPrint( "Your leg has been injured." )
		player:ChatPrint( "Now you have penalty for moving around." )
	end,
	ondebuffed = function( player, parameter )
		if not player:Alive() then return end
		player:ChatPrint( "Your leg has been restored." )
		player:ChatPrint( "Your movement penalty has been lifted." )
	end,
	func = function( player, parameter)
		player.timeNextMoan = player.timeNextMoan or CurTime()
		if player.timeNextMoan < CurTime() then
			player:EmitSound( Format( "vo/npc/male01/pain0%d.wav", math.random( 1, 9 ) ) )
			player.timeNextMoan = CurTime() + 5
		end
	end,
} 

PLUGIN.buffs[ "dehydrated" ] = {
	name = "Dehydrated",
	desc = "You're dehydrated.",
	func = function( player, parameter)
		player.timeNextDehydrated = player.timeNextDehydrated or CurTime()
		if player.timeNextDehydrated < CurTime() then
			player:EmitSound( Format( "ambient/voices/cough%d.wav", math.random( 1, 4 ) ) )
			player:ConCommand( "say /me coughs." )
			player.timeNextCough = CurTime() + 5
		end
	end,
} 

PLUGIN.buffs[ "starving" ] = {
	name = "Starving",
	desc = "You're starving.",
	func = function( player, parameter )
		player.timeNextHungry = player.timeNextHungry or CurTime()
		if player.timeNextHungry < CurTime() then
			player:EmitSound( Format( "ambient/voices/cough%d.wav", math.random( 1, 4 ) ) )
			player:ConCommand( "say /me coughs." )
			player.timeNextCough = CurTime() + 5
		end
	end,
}

PLUGIN.buffs[ "debuff_health" ] = {
	name = "Painful Pains",
	desc = "You're in deep pain of poison",
	func = function( player, parameter)
		player.timeNextPain = player.timeNextPain or CurTime()
		if player.timeNextPain < CurTime() then
			player:EmitSound( Format( "vo/npc/male01/pain0%d.wav", math.random( 1, 9 ) ) )
			player:TakeDamage( 2 )
			player.timeNextPain = CurTime() + 1
		end
	end,
}

PLUGIN.buffs[ "debuff_stamina" ] = {
	name = "Poisoned",
	desc = "You're in deep exaustation.",
	func = function( player, parameter)
		player.timeNextCough = player.timeNextCough or CurTime()
		player.timeNextStamina = player.timeNextStamina or CurTime()
		if player.timeNextCough < CurTime() then
			player:EmitSound( Format( "ambient/voices/cough%d.wav", math.random( 1, 4 ) ) )
			player:ConCommand( "say /me coughs." )
			player.timeNextCough = CurTime() + 10
		end
		if player.timeNextStamina < CurTime() then
			local stam = player.character:GetVar( "stamina" )
			player.character:SetVar( "stamina", stam - 20 )
			player.timeNextStamina = CurTime() + 5
		end
	end,
} 
