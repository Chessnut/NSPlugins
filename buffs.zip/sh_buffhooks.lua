/*-----------------------------------------------
						SAMPLE HOOKS FOR LEG BREAK
------------------------------------------------*/
function PLUGIN:PlayerNoClip( ply, bool )
	ply.OnNoclip = bool
end

function PLUGIN:Move( ply, mv ) -- Restricts movement when player has leg break buff
	if ply:GetMoveType() == 8 then return end
	if ply:HasBuff( "leghurt" ) and ply:GetMoveType() == MOVETYPE_WALK then
			local m = .25
			local f = mv:GetForwardSpeed() 
			local mf = math.Clamp( f * m, 0, ply:GetWalkSpeed() )
			local mfv = math.abs( math.sin( CurTime() * 3 ) ) * mf 
			mv:SetForwardSpeed( mfv )
			mv:SetSideSpeed( 0  )
	end
end

function PLUGIN:GetFallDamage( p, s ) -- Gives player leg break buff when he fell off on the ground with high speed.
	if s >= 650 then
		if self.FallLegBreak then
			timer.Simple( .1, function()
				if p:Alive() then
					p:AddBuff( "leghurt" )
				end
			end)
		end
	end
end

function PLUGIN:PlayerBindPress( p, b, prsd )
	if p:GetMoveType() == 8 then return end
	if p:HasBuff( "leghurt" ) then
		if ( string.find( b, "+speed" ) ) then return true end
	end
end



/*-----------------------------------------------
								
------------------------------------------------*/