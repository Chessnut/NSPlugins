/*-----------------------------------------------
						SAMPLE HOOKS FOR LEG BREAK
------------------------------------------------*/
local PLUGIN = PLUGIN
local playerMeta = FindMetaTable("Player")
function PLUGIN:PlayerNoClip( ply, bool )
	ply.OnNoclip = bool
end

function PLUGIN:Move( ply, mv ) -- Restricts movement when player has leg break buff
	if ply:GetMoveType() == 8 then return end
	if ply:HasBuff( "leghurt" ) and ply:GetMoveType() == MOVETYPE_WALK then
			local m = .25
			local f = mv:GetForwardSpeed() 
			local mf = math.Clamp( f * m, 0, ply:GetWalkSpeed() )
			local mfv = math.abs( math.sin( CurTime() * 3 ) ) * mf 
			mv:SetForwardSpeed( mfv )
			mv:SetSideSpeed( 0  )
	end
end

function PLUGIN:GetFallDamage( player, speed ) -- Gives player leg break buff when he fell off on the ground with high speed.
	if speed >= 650 then
		if self.legBreak then
			timer.Simple( .1, function()
				if player:Alive() then
					player:AddBuff( "leghurt" )
				end
			end)
		end
	end
end

function PLUGIN:PlayerBindPress( player, bind, prsd )
	if player:GetMoveType() == 8 then return end
	if player:HasBuff( "leghurt" ) then
		if ( string.find( bind, "+speed" ) ) then return true end
	end
end

local hitbones = {
	[HITGROUP_HEAD] = {
		"ValveBiped.Bip01_Head1",
		"ValveBiped.Bip01_Neck1",
	},
	[HITGROUP_CHEST] = {
		"ValveBiped.Bip01_Spine4",
		"ValveBiped.Bip01_Spine2",
	},
	[HITGROUP_STOMACH] = {
		"ValveBiped.Bip01_Spine1",
		"ValveBiped.Bip01_Spine",
	},
	[HITGROUP_LEFTARM] = {
		"ValveBiped.Bip01_L_UpperArm",
		"ValveBiped.Bip01_L_Forearm",
		"ValveBiped.Bip01_L_Hand",
	},
	[HITGROUP_RIGHTARM] = {
		"ValveBiped.Bip01_R_UpperArm",
		"ValveBiped.Bip01_R_Forearm",
		"ValveBiped.Bip01_R_Hand",
	},
	[HITGROUP_LEFTLEG] = {
		"ValveBiped.Bip01_L_Thigh",
		"ValveBiped.Bip01_L_Calf",
	},
	[HITGROUP_RIGHTLEG] = {
		"ValveBiped.Bip01_R_Thigh",
		"ValveBiped.Bip01_R_Calf",
	},
}

function PLUGIN:DoPlayerDeath( player )
	player:SetNetVar("radioactive", 0)
end

function PLUGIN:ScalePlayerDamage( player, hitbox, damageinfo )
	if hitbones[hitbox] then
		local isbullet = ( damageinfo:GetDamageType() == DMG_BULLET )
		if SERVER then
			if !nut.schema.Call( "BleedingImmune", player ) then
				if isbullet or ( math.Rand( 1, 100 ) <= self.bleedChance ) then
					player:AddBuff( "bleeding", 600, { bone = table.Random( hitbones[hitbox] ) } )
				end
			end
			if !nut.schema.Call( "LegImmune", player ) then
				if hitbox == HITGROUP_LEFTLEG or hitbox == HITGROUP_RIGHTLEG then
					player:AddBuff( "leghurt" )
				end
			end
		end
	end
end

local trg = 0
local cur = 0
function PLUGIN:HUDPaint()
	if LocalPlayer():HasBuff( "bleeding" ) then 
		trg = 20 + math.abs( math.sin( RealTime()*2 )*80 )
	else
		trg = 0
	end
	cur = Lerp( FrameTime()*3, cur, trg )
	surface.SetDrawColor( 255, 0, 0, cur)
	surface.DrawRect(0, 0, ScrW(), ScrH())
end


timer.Simple( 0, function() 
	local foodPLUGIN = nut.plugin.Get( "cookfood" )
	if not foodPLUGIN then
		print( 'Food hunger will not work properly without "cookfood" plugin!' )
	else
		function PLUGIN:FoodUsed( client, itemTable, data, entity )
			if itemTable.hunger > 0 then
				client:RemoveBuff( "starve" )
			end
			if itemTable.thirst > 0 then
				client:RemoveBuff( "thirst" )
			end
		end
		function PLUGIN:PlayerHunger( player )
			local character = player.character
			local hunger = character:GetVar("hunger", 0)
			if hunger <= 0 then
				player:AddBuff( "starve" )
			else
				if player:HasBuff( "starve" ) then
					player:RemoveBuff( "starve" )
				end
			end
		end
		function PLUGIN:PlayerThirst( player )
			local character = player.character
			local hunger = character:GetVar("thirst", 0)
			if hunger <= 0 then
				player:AddBuff( "thirst" )
			else
				if player:HasBuff( "thirst" ) then
					player:RemoveBuff( "thirst" )
				end
			end
		end
	end
end)

/*-----------------------------------------------
								
------------------------------------------------*/