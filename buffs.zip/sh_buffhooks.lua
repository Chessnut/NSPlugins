/*-----------------------------------------------
						SAMPLE HOOKS FOR LEG BREAK
------------------------------------------------*/
local PLUGIN = PLUGIN
function PLUGIN:PlayerNoClip( ply, bool )
	ply.OnNoclip = bool
end

function PLUGIN:Move( ply, mv ) -- Restricts movement when player has leg break buff
	if ply:GetMoveType() == 8 then return end
	if ply:HasBuff( "leghurt" ) and ply:GetMoveType() == MOVETYPE_WALK then
			local m = .25
			local f = mv:GetForwardSpeed() 
			local mf = math.Clamp( f * m, 0, ply:GetWalkSpeed() )
			local mfv = math.abs( math.sin( CurTime() * 3 ) ) * mf 
			mv:SetForwardSpeed( mfv )
			mv:SetSideSpeed( 0  )
	end
end

function PLUGIN:GetFallDamage( p, s ) -- Gives player leg break buff when he fell off on the ground with high speed.
	if s >= 650 then
		if self.FallLegBreak then
			timer.Simple( .1, function()
				if p:Alive() then
					p:AddBuff( "leghurt" )
				end
			end)
		end
	end
end

function PLUGIN:PlayerBindPress( p, b, prsd )
	if p:GetMoveType() == 8 then return end
	if p:HasBuff( "leghurt" ) then
		if ( string.find( b, "+speed" ) ) then return true end
	end
end

timer.Simple( 0, function() 
	local foodPLUGIN = nut.plugin.Get( "cookfood" )
	if not foodPLUGIN then
		print( 'Food hunger will not work properly without "cookfood" plugin!' )
	else
		function PLUGIN:FoodUsed( client, itemTable, data, entity )
			if itemTable.hunger > 0 then
				client:RemoveBuff( "starve" )
			end
			if itemTable.thirst > 0 then
				client:RemoveBuff( "thirst" )
			end
		end
		function PLUGIN:PlayerHunger( player )
			local character = player.character
			local hunger = character:GetVar("hunger", 0)
			if hunger <= 0 then
				player:AddBuff( "starve" )
			else
				if player:HasBuff( "starve" ) then
					player:RemoveBuff( "starve" )
				end
			end
		end
		function PLUGIN:PlayerThirst( player )
			local character = player.character
			local hunger = character:GetVar("thirst", 0)
			if hunger <= 0 then
				player:AddBuff( "thirst" )
			else
				if player:HasBuff( "thirst" ) then
					player:RemoveBuff( "thirst" )
				end
			end
		end
	end
end)

/*-----------------------------------------------
								
------------------------------------------------*/