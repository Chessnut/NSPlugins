/*-----------------------------------------------
						SAMPLE HOOKS FOR LEG BREAK
------------------------------------------------*/

function PLUGIN:Move( ply, mv ) -- Restricts movement when player has leg break buff.
	if ply:HasBuff( "leghurt" ) then
		local f = mv:GetForwardSpeed() 
		local s = mv:GetSideSpeed()
		local m = .01
		mv:SetForwardSpeed( f * m )
		mv:SetSideSpeed( s * m )
	end
end

function PLUGIN:GetFallDamage( p, s ) -- Gives player leg break buff when he fell off on the ground with high speed.
	if s >= 650 then
		if self.FallLegBreak then
			timer.Simple( .1, function()
				if p:Alive() then
					p:AddBuff( "leghurt" )
				end
			end)
		end
	end
end

/*-----------------------------------------------
								
------------------------------------------------*/