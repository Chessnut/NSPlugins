ITEM.name = "해독제"
ITEM.uniqueID = "buff_Detoxer"
ITEM.model = Model("models/Items/battery.mdl")
--ITEM.desc = "Overwatch Issue De-toxin purpose medical injector."
ITEM.desc = "오버와치가 제공하는 해독 목적의 의료 주입기."

ITEM.removebuff = {
	"posion"
}