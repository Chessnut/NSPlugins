local PLUGIN = PLUGIN
local playerMeta = FindMetaTable("Player")

function addParticle( emitter, data )
	if !data.mat then 
		return nil
	end
	local p = emitter:Add( data.mat, data.pos )
	p:SetVelocity( data.velocity or Vector( 0, 0, 0 ) )
	p:SetDieTime( data.lifetime or 1)
	data.alpha = data.alpha or {}
	p:SetStartAlpha( data.alpha[1] or 255 )
	p:SetEndAlpha( data.alpha[2] or 0 )
	data.size = data.size or {}
	p:SetStartSize( data.size[1] or 0 )
	p:SetEndSize( data.size[2] or 10 )
	if data.length then
		p:SetStartLength( data.length[1] or 10 )
		p:SetEndLength( data.length[2] or 10 )
	end
	/*
	p:SetRoll( data.roll or 0 )
	p:SetRollDelta( data.droll or 0 )
	*/
	if data.color then
		p:SetColor( unpack( data.color ) )
	else
		p:SetColor( 255, 255, 255 )
	end
	p:SetGravity( data.gravity or Vector( 0, 0, 0 )  )
	p:SetAirResistance( data.drag or 0 )
	return p
end 

-- BLURRY BLUR CODE FROM THE RAZBORKA
-- Thank you SPY!

function player:SetBlur( uid, amount )
	if !LocalPlayer() then
		return
	end
	LocalPlayer().blurTable = LocalPlayer().blurTable or {}
	LocalPlayer().blurTable[uid] = amount
end

function player:RemoveBlur( uid )
	if !LocalPlayer() then
		return
	end
	LocalPlayer().blurTable = LocalPlayer().blurTable or {}
	LocalPlayer().blurTable[uid] = amount
end

local curblur = 0
local tarblur = 0
local ps2 = render.SupportsPixelShaders_2_0()
local _Material			= Material("pp/toytown-top")
_Material:SetTexture("$fbtexture", render.GetScreenEffectTexture())
function PLUGIN:RenderScreenspaceEffects()
	tarblur = 0
	LocalPlayer().blurTable = LocalPlayer().blurTable or {}
	for k, v in pairs( LocalPlayer().blurTable ) do
		tarblur = tarblur + v
	end
	if tarblur > 0 and ps2 then
		x, y = ScrW(), ScrH()
		curblur = Lerp( FrameTime()*.5, curblur, tarblur)
		cam.Start2D()
			surface.SetMaterial(_Material)
			surface.SetDrawColor(255, 255, 255, 255)
			
			for i = 1, tarblur do
				render.UpdateScreenEffectTexture()
				surface.DrawTexturedRect(0, 0, x, y * 2)
			end

		cam.End2D()
	end
end

