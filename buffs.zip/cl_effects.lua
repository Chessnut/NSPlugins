local PLUGIN = PLUGIN
function addParticle( emitter, data )
	if !data.mat then 
		return nil
	end
	local p = emitter:Add( data.mat, data.pos )
	p:SetVelocity( data.velocity or Vector( 0, 0, 0 ) )
	p:SetDieTime( data.lifetime or 1)
	data.alpha = data.alpha or {}
	p:SetStartAlpha( data.alpha[1] or 255 )
	p:SetEndAlpha( data.alpha[2] or 0 )
	data.size = data.size or {}
	p:SetStartSize( data.size[1] or 0 )
	p:SetEndSize( data.size[2] or 10 )
	if data.length then
		p:SetStartLength( data.length[1] or 10 )
		p:SetEndLength( data.length[2] or 10 )
	end
	/*
	p:SetRoll( data.roll or 0 )
	p:SetRollDelta( data.droll or 0 )
	*/
	if data.color then
		p:SetColor( unpack( data.color ) )
	else
		p:SetColor( 255, 255, 255 )
	end
	p:SetGravity( data.gravity or Vector( 0, 0, 0 )  )
	p:SetAirResistance( data.drag or 0 )
	return p
end 

