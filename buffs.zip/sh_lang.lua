nut.lang.Add("stat_medical", "Medical")
nut.lang.Add("stat_medical_desc", "How good your medical skill is.")
--nut.lang.Get("desc_status")