ITEM.name = "SR-3M Vikhr"
ITEM.desc = "A compact, fully automatic assault rifle by the Russians."
ITEM.model = Model("models/weapons/w_dmg_vikhr.mdl")
ITEM.class = ITEM.uniqueID
ITEM.type = "rifle"
ITEM.price = 3000