ITEM.name = "FN SCAR"
ITEM.desc = "A modular rifle developed for the United States."
ITEM.model = Model("models/weapons/w_fn_scar_h.mdl")
ITEM.class = ITEM.uniqueID
ITEM.type = "rifle"
ITEM.price = 3250