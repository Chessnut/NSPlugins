ITEM.name = "AK-47"
ITEM.desc = "A Russian assault rifle with a red-dot sight attached."
ITEM.model = Model("models/weapons/w_dmg_vikhr.mdl")
ITEM.class = ITEM.uniqueID
ITEM.type = "rifle"
ITEM.price = 3250