ITEM.name = "H&K USP"
ITEM.desc = "A semi-automatic pistol developed in Germany."
ITEM.model = Model("models/weapons/w_pist_fokkususp.mdl")
ITEM.class = ITEM.uniqueID
ITEM.type = "pistol"
ITEM.price = 875