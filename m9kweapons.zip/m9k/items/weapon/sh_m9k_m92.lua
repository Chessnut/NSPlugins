ITEM.name = "M92 Beretta"
ITEM.desc = "A semi-automatic pistol designed and manufactured in Italy."
ITEM.model = Model("models/weapons/w_beretta_m92.mdl")
ITEM.class = ITEM.uniqueID
ITEM.type = "pistol"
ITEM.price = 800