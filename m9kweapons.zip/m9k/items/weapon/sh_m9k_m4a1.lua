ITEM.name = "M4A1"
ITEM.desc = "A fully automatic variant of the M4 carbine."
ITEM.model = Model("models/weapons/w_m4a1_iron.mdl")
ITEM.class = string.gsub(ITEM.uniqueID, "weapon_", "")
ITEM.type = "rifle"
ITEM.price = 4000