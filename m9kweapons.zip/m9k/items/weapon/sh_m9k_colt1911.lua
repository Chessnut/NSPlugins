ITEM.name = "Colt 1911"
ITEM.desc = "Standard issue pistol for the United States in 1911."
ITEM.model = Model("models/weapons/s_dmgf_co1911.mdl")
ITEM.class = ITEM.uniqueID
ITEM.type = "pistol"