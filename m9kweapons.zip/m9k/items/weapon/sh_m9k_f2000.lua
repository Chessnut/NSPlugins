ITEM.name = "FN F2000"
ITEM.desc = "A 5.56x45mm NATO bullpup assault rifle."
ITEM.model = Model("models/weapons/w_fn_f2000.mdl")
ITEM.class = ITEM.uniqueID
ITEM.type = "rifle"