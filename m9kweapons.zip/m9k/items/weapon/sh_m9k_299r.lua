ITEM.name = "SIG Sauer P229R"
ITEM.desc = "A full-sized, service-type pistol by SIG Sauer."
ITEM.model = Model("models/weapons/w_sig_229r.mdl")
ITEM.class = string.gsub(ITEM.uniqueID, "weapon_", "")
ITEM.type = "pistol"
ITEM.price = 1000