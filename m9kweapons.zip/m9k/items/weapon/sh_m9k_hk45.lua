ITEM.name = "HK45 Compact"
ITEM.desc = "An smaller version of the standard HK45."
ITEM.model = Model("models/weapons/w_hk45c.mdl")
ITEM.class = ITEM.uniqueID
ITEM.type = "pistol"