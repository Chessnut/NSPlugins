ITEM.name = "Famas"
ITEM.desc = "A French bullpup-styled assault rifle."
ITEM.model = Model("models/weapons/w_tct_famas.mdl")
ITEM.class = ITEM.uniqueID
ITEM.type = "rifle"