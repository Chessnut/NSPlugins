ITEM.name = "Glock"
ITEM.desc = "An Austrian semi-automatic pistol."
ITEM.model = Model("models/weapons/w_dmg_glock.mdl")
ITEM.class = ITEM.uniqueID
ITEM.type = "pistol"