ITEM.name = "Glock"
ITEM.desc = "An Austrian semi-automatic pistol."
ITEM.model = Model("models/weapons/w_dmg_glock.mdl")
ITEM.class = string.gsub(ITEM.uniqueID, "weapon_", "")
ITEM.type = "pistol"
ITEM.price = 750