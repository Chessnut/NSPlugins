ITEM.name = "IMI Tavor TAR-21"
ITEM.desc = "An Israeli bullpup assault rifle."
ITEM.model = Model("models/weapons/w_imi_tar21.mdl")
ITEM.class = ITEM.uniqueID
ITEM.type = "rifle"