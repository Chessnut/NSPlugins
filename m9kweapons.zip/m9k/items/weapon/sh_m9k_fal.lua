ITEM.name = "FN FAL"
ITEM.desc = "A self-loading battle rifle produced by the Belgians."
ITEM.model = Model("models/weapons/w_fn_fal.mdl")
ITEM.class = ITEM.uniqueID
ITEM.type = "rifle"
ITEM.price = 3000