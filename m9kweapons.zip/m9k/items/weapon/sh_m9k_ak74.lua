ITEM.name = "AK-74"
ITEM.desc = "A modernized version of the AK-47."
ITEM.model = Model("models/weapons/w_ak47_m9k.mdl")
ITEM.class = string.gsub(ITEM.uniqueID, "weapon_", "")
ITEM.price = 4000