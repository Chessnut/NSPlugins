ITEM.name = "ACR"
ITEM.desc = "An adaptive combat rifle."
ITEM.model = Model("models/weapons/w_masada_acr.mdl")
ITEM.class = ITEM.uniqueID
ITEM.type = "rifle"
ITEM.price = 2750