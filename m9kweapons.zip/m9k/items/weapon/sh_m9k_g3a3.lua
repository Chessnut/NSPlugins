ITEM.name = "HK G3A3"
ITEM.desc = "A 7.62x51mm NATO battle rifle developed by the Germans."
ITEM.model = Model("models/weapons/w_hk_g3.mdl")
ITEM.class = ITEM.uniqueID
ITEM.type = "rifle"