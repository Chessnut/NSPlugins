ITEM.name = "AS VAL"
ITEM.desc = "A Russian assault rifle developed during the late 1980s."
ITEM.model = Model("models/weapons/w_dmg_vally.mdl")
ITEM.class = ITEM.uniqueID
ITEM.type = "rifle"