ITEM.name = "73 Winchester Carbin"
ITEM.desc = "A lever-action rifle by the Winchester Repeating Arms Company."
ITEM.model = Model("models/weapons/w_winchester_1873.mdl")
ITEM.class = "m9k_winchester73"
ITEM.type = "rifle"
ITEM.price = 5000