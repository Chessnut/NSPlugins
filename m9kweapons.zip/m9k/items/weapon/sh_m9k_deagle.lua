ITEM.name = "Desert Eagle"
ITEM.desc = "A powerful semi-automatic pistol."
ITEM.model = Model("models/weapons/w_tcom_deagle.mdl")
ITEM.class = ITEM.uniqueID
ITEM.type = "pistol"
ITEM.price = 1000