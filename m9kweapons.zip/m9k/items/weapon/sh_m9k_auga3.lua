ITEM.name = "Steyr AUG A3"
ITEM.desc = "A rifle adopted by the Austrian Army, and it has a scope."
ITEM.model = Model("models/weapons/w_auga3.mdl")
ITEM.class = ITEM.uniqueID
ITEM.type = "rifle"