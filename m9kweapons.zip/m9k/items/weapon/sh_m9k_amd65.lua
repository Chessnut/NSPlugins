ITEM.name = "AMD 65"
ITEM.desc = "A Hungrary variant of the AKM rifle."
ITEM.model = Model("models/weapons/w_amd_65.mdl")
ITEM.class = string.gsub(ITEM.uniqueID, "weapon_", "")
ITEM.type = "rifle"
ITEM.price = 2500