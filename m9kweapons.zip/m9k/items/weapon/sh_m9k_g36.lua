ITEM.name = "G36"
ITEM.desc = "Designed in Germany as a replacement for the G3 battle rifle."
ITEM.model = Model("models/weapons/w_hk_g36c.mdl")
ITEM.class = string.gsub(ITEM.uniqueID, "weapon_", "")
ITEM.type = "rifle"
ITEM.price = 4000