ITEM.name = "G36"
ITEM.desc = "Designed in Germany as a replacement for the G3 battle rifle."
ITEM.model = Model("models/weapons/w_hk_g36c.mdl")
ITEM.class = ITEM.uniqueID
ITEM.type = "rifle"