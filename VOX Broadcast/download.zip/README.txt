This plugin adds a small category in the in-game help menu.
I suggest you to watch it when you're in-game.

/v, /vox, /announce to announce vox voice.
unregistered voice will not emit the sound.

