PLUGIN.name = "New Animations"
PLUGIN.author = "Green, Kelse"
PLUGIN.desc = "Creates better animations for holding weapons."

nut.util.Include("sh_animations.lua")